import 'dart:math';
import 'dart:ui' as ui;
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;

import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flame/palette.dart';
import 'package:flutter/painting.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_soloud/flutter_soloud.dart';
import 'package:flame/effects.dart';

import 'player.dart';
import 'remote_player.dart';
import 'floating_text.dart';
import 'bot_player.dart'; 
import 'game_map.dart';
import 'darkness_overlay.dart';
import 'jump_scare_effect.dart';
import 'score_hud.dart';
import 'game_timer.dart';
import 'start_button.dart';
import 'attack_button.dart';
import 'defense_button.dart';
import 'player_hud.dart';
import 'scare_blast.dart';
import 'level_manager.dart';
import 'tutorial_manager.dart';
import 'power_up.dart';
import 'power_up_hud.dart';
import 'spooky_box.dart';
import 'special_button.dart';
import 'chest_reward.dart';
import 'mask_data.dart';
import 'flying_scare_blast.dart';
import 'critter.dart';
import 'vessel_opener_overlay.dart';
import 'scare_manager.dart';
import 'flashlight_hud.dart';
import 'siren_blast.dart';
import 'map_overlay.dart';
import 'map_button.dart';
import 'fps_viewport_overlay.dart';
import 'mode_toggle_button.dart';
import 'fps_touch_controls.dart';
import 'audio_manager.dart';
import 'character_asset_manager.dart';
import 'hallway_triggers.dart';
import 'puzzle_manager.dart';
import 'chat_bubble_component.dart';
import 'quick_chat_wheel.dart';

class ScareSnapshot {
  final String attackerName;
  final String attackerCharId;
  final String attackerMaskId;
  final String victimName;
  final String victimCharId;
  final String victimMaskId;
  final String? victimId;
  final int timestamp; 
  final double mapX;
  final double mapY;

  ScareSnapshot({
    required this.attackerName,
    required this.attackerCharId,
    required this.attackerMaskId,
    required this.victimName,
    required this.victimCharId,
    required this.victimMaskId,
    this.victimId,
    required this.timestamp,
    required this.mapX,
    required this.mapY,
  });
}

class GraveStakesGame extends FlameGame with HasKeyboardHandlerComponents, HasCollisionDetection {
  static List<ScareSnapshot> lastMatchPhotos = [];
  // --- Lumen Delta Tracking ---
  int matchLumenDelta = 0;
  String roomId;
  final bool isGunner;
  final String? driverId;
  final bool hasGunner;
  final String matchMode; 
  final String mapName;
  final int targetPlayers;
  final bool isGuildScrimmage;
  final String? scrimmageMessageId;
  String? myGuildId;
  String guildActiveDoctrine = 'none';
  final String chaosModifier;

  bool isPuzzleRoomOccupied = false;
  bool isHallwaySolved = false;

  bool isGlobalBlackout = false;
  double blackoutTimer = 0.0;

  // Triggers somewhere between 60 and 120 seconds into the match
  double timeUntilNextBlackout = 60.0 + Random().nextDouble() * 60.0;
  bool willBlackoutHappen = Random().nextBool(); // 50% chance per match
  bool hasBlackoutFired = false;

  bool isWaitingInLobby = true;

  bool matchHasHunter = false;
  bool hunterHasSpawned = false;

  String matchPhase = 'searching'; 
  double lobbyTimer = 10.0;
  double countdownTimer = 3.0;
  int _lastTick = 4; // Ensures the first tick fires immediately at 3.0!

  double cinematicTimer = 0.0;
  bool cinematicStage1 = false, cinematicStage2 = false, cinematicStage3 = false, cinematicStage4 = false;
  BotPlayer? stuntDoubleHero;
  BotPlayer? cinematicMonster;
  TextComponent? cinematicStatusText;
  
  static Map<String, Map<String, ui.Image>> characterImagesCache = {};
  static Map<String, Map<String, dynamic>> characterRigCache = {};
  
  Map<String, ui.Image> loadedAssetImages = {};
  Map<String, dynamic>? loadedRigData;
  bool isFpsMode = false;

  Map<String, int> playerTeams = {};

  bool _isFavoredPrey(String attackerSpecies, String victimSpecies) {
    final a = attackerSpecies.toLowerCase();
    final v = victimSpecies.toLowerCase();
    if (a.contains('ghost') && v.contains('humanoid')) return true;
    if (a.contains('humanoid') && v.contains('cybernetic')) return true;
    if (a.contains('cybernetic') && v.contains('alien')) return true;
    if (a.contains('alien') && v.contains('beast')) return true;
    if (a.contains('beast') && v.contains('ghost')) return true;
    return false;
  }

  bool _matchesDoctrine(dynamic target) {
    if (guildActiveDoctrine == 'none') return false;
    String targetSpecies = 'humanoid'; 
    try {
      targetSpecies = target.species ?? 'humanoid';
    } catch (_) {
      targetSpecies = 'humanoid';
    }
    return targetSpecies == guildActiveDoctrine;
  }

  int getEntityTeam(dynamic entity) {
    if (matchMode != '2v2') return 0; 
    
    if (entity is Player) return playerTeams[mySessionId] ?? 1;
    if (entity is BotPlayer) return entity.teamId;
    if (entity is String) return playerTeams[entity] ?? 0; 
    
    if (entity is RemotePlayer) {
      String? remoteId;
      networkPlayers.forEach((key, val) { if (val == entity) remoteId = key; });
      return playerTeams[remoteId] ?? 0;
    }
    return 0;
  }
  
  GraveStakesGame({
    this.roomId = 'public_match', 
    this.isGunner = false,
    this.driverId,
    this.hasGunner = false,
    this.mapName = 'L1T1V1.0.0',
    this.matchMode = 'casual',
    this.targetPlayers = 8,
    this.isGuildScrimmage = false,
    this.scrimmageMessageId,
    this.chaosModifier = 'none',
  });

  late final JoystickComponent leftJoystick;
  late final JoystickComponent rightJoystick;
  late final Player player;
  late final ScareManager scareManager;
  late final PuzzleManager puzzleManager;

  late final String mySessionId; 
  bool isHost = false; 
  Map<String, RemotePlayer> networkPlayers = {}; 

  late final JumpScareEffect jumpScareEffect;
  late final GameMap gameMap; 

  late MapOverlay mapOverlay;

  late final GameTimer gameTimer;
  late final ScoreHud scoreHud;
  bool gameStarted = false;
  int myPlayerLevel = 1; 
  String myUsername = 'Ghost';
  
  final List<BotPlayer> bots = [];
  final List<ScareSnapshot> matchPhotos = [];

  final int maxMatchPhotos = Random().nextDouble() < 0.20 ? 2 : 1;

  @override
  void lifecycleStateChange(AppLifecycleState state) {
    super.lifecycleStateChange(state);

    if (!gameStarted || matchPhase != 'playing') return;

    if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      // Punish them instantly with inverted controls and camera scramble
      player.applyDissonance(10.0);
      
      // Optional: Broadcast the scramble so other players see the debuff effects
      myChannel.sendBroadcastMessage(
        event: 'dissonance', 
        payload: {'id': mySessionId, 'duration': 10.0}
      );
    }
  }

  void logScareSnapshot(ScareSnapshot snapshot, {required bool isHuman}) {
    // 1. One snapshot max per victim ID to prevent duplicates of the same player
    if (matchPhotos.any((p) => p.victimName == snapshot.victimName)) return;

    // 2. Add normally if under capacity
    if (matchPhotos.length < maxMatchPhotos) {
      matchPhotos.add(snapshot);
      return;
    }

    // 3. If full, a human scare will overwrite an existing bot scare
    if (isHuman) {
      int botIndex = matchPhotos.indexWhere((p) => !p.victimName.startsWith('Player '));
      if (botIndex != -1) {
        matchPhotos[botIndex] = snapshot;
      }
    }
  }

  double hostBotSyncTick = 0;
  final double hostBotSyncRate = 0.12;

  late final RealtimeChannel myChannel;

  void broadcastStartGame() async {
    myChannel.sendBroadcastMessage(event: 'match_control', payload: {'action': 'start'});
    triggerLocalStart(); 
    try {
      await Supabase.instance.client.from('active_matches').update({'status': 'playing'}).eq('id', roomId);
    } catch (e) {}
  }

  void resetForNextRound() async {
    overlays.remove('summary'); 
    player.score = 0;
    player.hasExtendedRange = false; 
    player.isDisguised = false;      
    player.isInvisible = false;      

    for (var remote in networkPlayers.values) remote.score = 0; 
    
    List<Vector2> availableSpawns = List.from(baseSpawnPoints)..shuffle();
    player.position = gameMap.getSafeSpawnLocation(availableSpawns.first, Vector2.all(32.0));
    camera.viewport.add(StartButton()); 
    final hud = camera.viewport.children.whereType<PlayerHud>().firstOrNull;
    hud?.fetchPlayerData();

    if (isHost) {
      try {
        await Supabase.instance.client.from('active_matches').update({'status': 'waiting'}).eq('id', roomId);
      } catch (e) {}
    }
  }

  final List<Vector2> baseSpawnPoints = [
    Vector2(150, 150),     
    Vector2(1770, 1770),   
    Vector2(1770, 150),    
    Vector2(150, 1770),    
    Vector2(960, 150),     
    Vector2(960, 1770),    
    Vector2(150, 960),     
    Vector2(1770, 960),    
  ];

  Future<void> _loadVoxelAssets() async {
    try {
      // ONLY load the default base mesh on startup. Do not query the DB!
      final ByteData data = await rootBundle.load('assets/character_assets.zip');
      final List<int> bytes = data.buffer.asUint8List();
      final archive = ZipDecoder().decodeBytes(bytes);
      
      for (final file in archive) {
        if (file.isFile) {
          if (file.name == 'rig.json') {
            final jsonStr = utf8.decode(file.content as List<int>);
            loadedRigData = jsonDecode(jsonStr);
          } else if (file.name.endsWith('.png')) {
            final ui.Codec codec = await ui.instantiateImageCodec(file.content as Uint8List);
            final ui.FrameInfo frameInfo = await codec.getNextFrame();
            loadedAssetImages[file.name] = frameInfo.image;
          }
        }
      }
      // Expose the default assets to the Polaroid Studio! ---
      if (loadedRigData != null) {
        characterRigCache['default'] = loadedRigData!;
        characterImagesCache['default'] = loadedAssetImages;
      }
    } catch (e) {
      debugPrint('CRITICAL: Default zip failed to load: $e');
    }
  }
  

  @override
  Future<void> onLoad() async {
    await images.load('Base_BaseChip_pipo.png');
    await images.loadAll([
      'standard_mask.png', 
      'flying_mask.png', 
      'vermin_mask.png', 
      'siren_mask.png'
    ]);

    await _loadVoxelAssets(); 

    mySessionId = DateTime.now().millisecondsSinceEpoch.toString();
    final user = Supabase.instance.client.auth.currentUser;
    bool needsTutorial = false;

    if (user != null) {
      try {
        final profileRes = await Supabase.instance.client
            .from('profiles')
            .select('completed_tutorial, level, username') // <-- Add username here
            .eq('id', user.id)
            .maybeSingle();
            
        if (profileRes != null) {
          needsTutorial = !(profileRes['completed_tutorial'] ?? false);
          myPlayerLevel = profileRes['level'] as int? ?? 1;
          myUsername = profileRes['username'] as String? ?? 'Ghost'; // <-- Store it here
        }

        final membership = await Supabase.instance.client
            .from('guild_members')
            .select('guild_id, guilds(active_doctrine)')
            .eq('user_id', user.id)
            .maybeSingle();
            
        if (membership != null && membership['guilds'] != null) {
          myGuildId = membership['guild_id'];
          guildActiveDoctrine = membership['guilds']['active_doctrine'] ?? 'none';
        }
      } catch (e) {}
    }
    
    myChannel = Supabase.instance.client.channel('room_$roomId');
    camera.viewfinder.anchor = Anchor.center;

    final knobPaint = BasicPalette.white.withAlpha(100).paint();
    final backgroundPaint = BasicPalette.white.withAlpha(40).paint();

    leftJoystick = JoystickComponent(
      knob: CircleComponent(radius: 20, paint: knobPaint),
      background: CircleComponent(radius: 60, paint: backgroundPaint),
      margin: const EdgeInsets.only(left: 40, bottom: 40),
      priority: 100,
    );

    rightJoystick = JoystickComponent(
      knob: CircleComponent(radius: 20, paint: Paint()..color = Colors.redAccent.withAlpha(204)),
      background: CircleComponent(radius: 60, paint: backgroundPaint),
      margin: const EdgeInsets.only(right: 40, bottom: 40),
      priority: 100,
    );

    gameMap = GameMap(roomId: roomId, mapName: mapName); 
    await world.add(gameMap);

    scareManager = ScareManager();
    await world.add(scareManager);

    puzzleManager = PuzzleManager();
    await world.add(puzzleManager);

    List<Vector2> availableSpawns = gameMap.playerSpawns.isNotEmpty 
        ? List<Vector2>.from(gameMap.playerSpawns)
        : [Vector2(150, 150), Vector2(400, 400)]; 
    
    availableSpawns.shuffle(); 
    final rawSpawnPoint = availableSpawns.removeAt(0);
    final safeSpawnPoint = gameMap.getSafeSpawnLocation(rawSpawnPoint, Vector2.all(32.0));

    player = Player(leftJoystick, rightJoystick, myChannel, isGunner: isGunner)..position = safeSpawnPoint;
    jumpScareEffect = JumpScareEffect();

    // --- INJECT LOCAL DUMMY FOR TESTING of co-op ---
    // --- INJECT LOCAL DUMMY FOR TESTING ---
    if (driverId == 'dummy_driver_123') {
      final dummyDriver = RemotePlayer()..position = safeSpawnPoint.clone() + Vector2(100, 0);
      dummyDriver.facingAngle = 0.0;
      dummyDriver.equippedCharacterId = 'default'; 
      dummyDriver.applyTeamColor(1); // Glows Blue
      
      networkPlayers['dummy_driver_123'] = dummyDriver;
      world.add(dummyDriver);
      
      dummyDriver.add(MoveEffect.by(
        Vector2(400, 0), 
        EffectController(duration: 4.0, reverseDuration: 4.0, infinite: true)
      ));

      // ADD THIS: Rotates the dummy 45 degrees (pi / 4) every 2 seconds
      dummyDriver.add(TimerComponent(
        period: 2.0,
        repeat: true,
        onTick: () {
          dummyDriver.facingAngle += pi / 4;
        },
      ));

      // Add a giant sign to prove you are in the sandbox
      camera.viewport.add(FloatingText(
        text: 'I AM THE DUMMY', 
        worldPosition: dummyDriver.position - Vector2(40, 60)
      ));
    }
    // --------------------------------------

    world.add(player);
    camera.follow(player);

    // --- TEMP: INJECT BLATANT TEST TRAPDOOR ---
    //world.add(Trapdoor(position: safeSpawnPoint + Vector2(100, 0)));

    camera.viewport.add(jumpScareEffect);
    camera.viewport.add(DarknessOverlay(player));

    // Ensure the 3D raycaster is always added
    await camera.viewport.add(FpsViewportOverlay());

    // Initialize the timer in memory so Player.update doesn't crash
    gameTimer = GameTimer();

    if (matchMode == 'cinematic') {
      matchPhase = 'cinematic';
      gameStarted = true;
      isFpsMode = true; 

      final stageX = 15 * 64.0; 
      final stageY = 15 * 64.0; 

      player.position = Vector2(stageX, stageY + 128); 
      player.facingAngle = 0.0; 
      player.isInvisible = true; 

      stuntDoubleHero = BotPlayer(isHunter: false)
        ..position = Vector2(stageX + 400, stageY - 64) 
        ..wanderSpeed = 0.0
        ..huntSpeed = 0.0
        ..priority = 10;
      stuntDoubleHero!.assignedCharacterId = player.equippedCharacterId;

      cinematicMonster = BotPlayer(isHunter: false) 
        ..position = Vector2(stageX + 800, stageY - 64) 
        ..wanderSpeed = 0.0
        ..huntSpeed = 0.0
        ..priority = 10;

      world.add(stuntDoubleHero!);
      world.add(cinematicMonster!);
      
      bots.add(stuntDoubleHero!);
      bots.add(cinematicMonster!);

      // --- MOVED HERE SO IT LOADS IN CINEMATIC MODE ---
      cinematicStatusText = TextComponent(
        text: 'WAITING FOR CLAPBOARD...',
        position: Vector2(camera.viewport.size.x / 2, 20),
        anchor: Anchor.topCenter,
        priority: 500,
        textRenderer: TextPaint(
          style: const TextStyle(
            color: Colors.cyanAccent,
            fontSize: 14,
            fontWeight: FontWeight.bold,
            fontFamily: 'Courier',
            shadows: [Shadow(color: Colors.black, blurRadius: 6)],
          ),
        ),
      );
      camera.viewport.add(cinematicStatusText!);

    } else {
      // --- NORMAL GAME UI & CONTROLS ---
      world.add(PowerUpHud(player: player));

      /* if (isGunner) {
        camera.viewport.add(rightJoystick);
      } else {
        camera.viewport.add(leftJoystick);
      } */
     camera.viewport.add(leftJoystick); // leftJoystick automatically adjusts for co-op mode now

      camera.viewport.add(ScoreHud());

      // Add the pre-initialized timer to the screen
      camera.viewport.add(gameTimer);
      
      await camera.viewport.add(FpsTouchControls());
      await camera.viewport.add(ModeToggleButton());

      camera.viewport.add(QuickChatWheel());

      mapOverlay = MapOverlay();
      await camera.viewport.add(mapOverlay);
      await camera.viewport.add(MapButton());

      

      try {
        final logoSprite = await Sprite.load('lumen_breach_small.jpg');
        final logoComponent = SpriteComponent(
          sprite: logoSprite,
          size: Vector2(120, 60), 
          position: Vector2(camera.viewport.size.x / 2, camera.viewport.size.y - 20), 
          anchor: Anchor.bottomCenter,
          priority: 200, 
        );
        camera.viewport.add(logoComponent);
      } catch (e) {}

      if (matchMode == 'casual') {
        matchPhase = 'playing'; 
        camera.viewport.add(StartButton());
      } else {
        overlays.add('searching');
      }
      
      camera.viewport.add(AttackButton());
      camera.viewport.add(DefenseButton());
      camera.viewport.add(PlayerHud());
      camera.viewport.add(FlashlightHud());
      camera.viewport.add(SpecialButton());

      if (needsTutorial) {
        gameStarted = true;
        gameTimer.start();
        camera.viewport.children.whereType<StartButton>().toList().forEach((btn) => btn.removeFromParent());
        world.add(PowerUp(id: 'tutorial_spark', position: safeSpawnPoint + Vector2(100, 0)));
        camera.viewport.add(TutorialManager());
      }
    }

    _setupSupabaseListener();
  }

 @override
  void update(double dt) {
    super.update(dt);

    if (matchPhase == 'cinematic') {
      if (stuntDoubleHero?.voxelComponent == null || cinematicMonster?.voxelComponent == null) {
        return; 
      }

      final stageX = 15 * 64.0; // X = 960
      final stageY = 15 * 64.0; // Y = 960

      // --- THE BULLDOZER & INITIAL STAGE SETUP ---
      if (cinematicTimer == 0.0) {
        world.children.whereType<WallComponent>().forEach((wall) {
          if (wall.position.x > stageX - 1500 && wall.position.x < stageX + 1500 &&
              wall.position.y > stageY - 1000 && wall.position.y < stageY + 1000) {
            wall.removeFromParent();
          }
        });

        // Spawn a custom 2-block "Prop Wall" for Beat 3's corner hiding scene
        world.add(WallComponent(position: Vector2(stageX - 200, stageY + 150), tileSize: 64.0));
        world.add(WallComponent(position: Vector2(stageX - 200, stageY + 214), tileSize: 64.0));

        // BEAT 1-2 SETUP: The Runway
        player.position = Vector2(stageX - 100, stageY - 14); 
        player.facingAngle = (pi / 2) - (25 * (pi / 180)); 
        player.isInvisible = true;

        stuntDoubleHero!.position = Vector2(stageX + 400, stageY - 64);
        cinematicMonster!.position = Vector2(stageX + 800, stageY - 64);
      }

      cinematicTimer += dt;
      super.update(dt); 

      // --- SCRIPT MONITOR TEXT UPDATER ---
      String currentBeat = 'WAITING';
      if (cinematicTimer <= 5.0) currentBeat = 'BEAT 1-2: FLY-BY';
      else if (cinematicTimer <= 10.0) currentBeat = 'BEAT 3: CORNER CREEP (EXT)';
      else if (cinematicTimer <= 13.0) currentBeat = 'BEAT 4: FPS POV';
      else if (cinematicTimer <= 15.0) currentBeat = 'BEAT 5: BLACKOUT';
      else if (cinematicTimer <= 20.0) currentBeat = 'BEAT 6: EMPTY TURN';
      else if (cinematicTimer <= 23.0) currentBeat = 'BEAT 7: SNAP SCARE';
      else currentBeat = 'SCENE END';

      cinematicStatusText?.text = 'TIME: [${cinematicTimer.toStringAsFixed(2)}s] | $currentBeat';

      // --- CINEMATIC AI LOCKS ---
      if (stuntDoubleHero != null && stuntDoubleHero!.parent != null) {
         stuntDoubleHero!.attackCooldown = 999.0; 
         stuntDoubleHero!.wanderSpeed = 0.0;
         stuntDoubleHero!.huntSpeed = 0.0;
         stuntDoubleHero!.isStunned = false;
         if (stuntDoubleHero!.voxelComponent != null) {
             stuntDoubleHero!.voxelComponent!.isMoving = cinematicTimer < 5.0; 
         }
      }
      
      if (cinematicMonster != null && cinematicMonster!.parent != null) {
         cinematicMonster!.attackCooldown = 999.0; 
         cinematicMonster!.wanderSpeed = 0.0;
         cinematicMonster!.huntSpeed = 0.0;
         cinematicMonster!.isStunned = false;
         if (cinematicMonster!.voxelComponent != null) {
             // Monster runs in Beat 1, and walks in Beat 3
             cinematicMonster!.voxelComponent!.isMoving = (cinematicTimer < 5.0) || (cinematicTimer >= 5.0 && cinematicTimer < 9.0);
             try { cinematicMonster!.voxelComponent!.activeMaskImage ??= images.fromCache('siren_mask.png'); } catch(e){}
         }
      }

      // BEAT 1 & 2: The Fly-By (0s - 5s)
      if (cinematicTimer > 0.5 && !cinematicStage1) {
        cinematicStage1 = true;
        stuntDoubleHero!.facingAngle = -pi / 2;
        cinematicMonster!.facingAngle = -pi / 2;

        stuntDoubleHero!.add(MoveToEffect(Vector2(stageX - 400, stageY - 64), EffectController(duration: 2.0)));
        Future.delayed(const Duration(milliseconds: 1800), () {
          cinematicMonster!.add(MoveToEffect(Vector2(stageX - 400, stageY - 64), EffectController(duration: 1.2)));
        });
      }

      // BEAT 3: External Corner Creep (5s - 10s)
      bool cinematicStage2 = cinematicTimer > 5.0;
      if (cinematicStage2 && cinematicTimer < 5.1) { // Trigger exactly once at 5.0
        // Hero hides on the East side of the wall, facing North
        stuntDoubleHero!.position = Vector2(stageX - 100, stageY + 250);
        stuntDoubleHero!.facingAngle = 0.0;

        // Camera moves to North-East, looking South-West at the Hero and Wall
        player.position = Vector2(stageX - 50, stageY + 100);
        player.facingAngle = (3 * pi) / 4; 

        // Monster starts West of the wall, creeps Eastwards towards the corner edge
        cinematicMonster!.position = Vector2(stageX - 500, stageY + 150);
        cinematicMonster!.facingAngle = pi / 2; // Facing East
        
        // Creep slowly to just behind the corner wall
        cinematicMonster!.add(MoveToEffect(Vector2(stageX - 250, stageY + 150), EffectController(duration: 4.0)));
      }

      // BEAT 4: FPS POV Cut (10s - 13s)
      bool cinematicStage3 = cinematicTimer > 10.0;
      if (cinematicStage3 && cinematicTimer < 10.1) {
        stuntDoubleHero!.position = Vector2(-9999, -9999); 
        
        // Camera snaps into Hero's exact position behind the wall, looking North
        player.position = Vector2(stageX - 100, stageY + 250);
        player.facingAngle = 0.0; 
        player.isInvisible = false;
      }

      // BEAT 5: The Blackout (13s - 15s)
      bool cinematicStage4 = cinematicTimer > 13.0;
      if (cinematicStage4 && cinematicTimer < 13.1) {
        player.flashlightBattery = 0.0;
        player.isFlashlightDead = true; 
      }

      // BEAT 6: Light Returns & First Slow Turn (15s - 20s)
      bool cinematicStage5 = cinematicTimer > 15.0;
      if (cinematicStage5 && cinematicTimer < 15.1) {
        player.flashlightBattery = 100.0; 
        player.isFlashlightDead = false;

        // Teleport Monster 25 pixels directly behind (South of) the player's new position!
        cinematicMonster!.position = player.position + Vector2(0, 25); 
        cinematicMonster!.facingAngle = 0.0; // Looking at the back of Hero's head
      }

      if (cinematicTimer > 15.0 && cinematicTimer <= 20.0) {
        double turnProgress = cinematicTimer - 15.0;
        
        // 15s to 18s: Slow 90-degree sweep to the Right (North to East)
        if (turnProgress <= 3.0) {
          player.facingAngle = (turnProgress / 3.0) * (pi / 2);
        }
        // 18s to 20s: The Pause (Hold exactly East, seeing nothing)
        else {
          player.facingAngle = pi / 2;
        }
      }

      // BEAT 7: Snap Turn & Jump Scare (20s - 23s)
      if (cinematicTimer > 20.0) {
        double snapTime = cinematicTimer - 20.0;
        
        // 20.0s to 20.5s: Exponentially accelerating 90-degree turn to South
        if (snapTime <= 0.5) {
          // Cubing the progress creates a slow start that violently snaps at the end
          double curve = pow(snapTime / 0.5, 3).toDouble();
          player.facingAngle = (pi / 2) + (curve * (pi / 2));
        } else {
          player.facingAngle = pi; // Lock facing South (Looking right at the monster)
        }

        // 20.5s: SCARE TRIGGER (Exactly as the camera locks onto South)
        if (snapTime > 0.5 && snapTime < 0.55) {
          if (cinematicMonster!.voxelComponent != null) {
              cinematicMonster!.voxelComponent!.triggerScareAnimation('siren');
          }
          if (AudioManager.instance.isInitialized && AudioManager.instance.impactSource != null) {
            SoLoud.instance.play(AudioManager.instance.impactSource!); 
          }
        }

        // 20.7s: FINAL CUT TO BLACK
        if (snapTime >= 0.7) {
          player.flashlightBattery = 0.0;
          player.isFlashlightDead = true;
          pauseEngine();
        }
      }
      return;
    }
    
    if (matchPhase == 'searching') {
      if (isHost) {
        lobbyTimer -= dt;

        if (isHost && gameStarted && matchHasHunter && !hunterHasSpawned) {
          if (gameTimer.timeLeft <= 60.0 && gameTimer.timeLeft > 0) {
            final eligibleBots = bots.where((b) => !b.isHunter).toList();
            if (eligibleBots.isNotEmpty) {
              hunterHasSpawned = true;
              final chosenBot = eligibleBots[Random().nextInt(eligibleBots.length)];
              final botIndex = bots.indexOf(chosenBot);

              chosenBot.transformToHunter();
              myChannel.sendBroadcastMessage(
                event: 'hunter_emerge',
                payload: {'bot_index': botIndex},
              );
            }
          }
        }
        
        int totalHumans = 1 + networkPlayers.length;
        
        bool shouldStart = totalHumans >= targetPlayers || (!isGuildScrimmage && lobbyTimer <= 0);
        
        if (shouldStart) {
          _spawnWorldEntities(); 
          matchPhase = 'countdown';
          overlays.remove('searching');
          overlays.add('countdown');
          myChannel.sendBroadcastMessage(
            event: 'start_countdown', 
            payload: {'teams': playerTeams}
          );
        }
      }
      return; 
    }

    if (isHost && gameStarted && matchPhase == 'playing') {
      // --- 50/50 Chance, Once Per Match ---
      if (willBlackoutHappen && !hasBlackoutFired) {
        timeUntilNextBlackout -= dt;
        if (timeUntilNextBlackout <= 0) {
          hasBlackoutFired = true;
          isGlobalBlackout = true;
          blackoutTimer = 30.0;
          
          myChannel.sendBroadcastMessage(event: 'global_blackout', payload: {'active': true, 'duration': 30.0});
          if (!player.isInPuzzleRoom) {
            camera.viewport.add(FloatingText(
              text: 'TOTAL BLACKOUT!', 
              worldPosition: Vector2(player.position.x - 40, player.position.y - 60)
            ));
          }
        }
      }

      if (isGlobalBlackout) {
        blackoutTimer -= dt;
        if (blackoutTimer <= 0) {
          isGlobalBlackout = false;
          myChannel.sendBroadcastMessage(event: 'global_blackout', payload: {'active': false});
        }
      }
    }

    if (matchPhase == 'countdown') {
      countdownTimer -= dt;
      int currentTick = countdownTimer.ceil();
      
      if (currentTick < _lastTick && currentTick > 0) {
        _lastTick = currentTick;
        if (AudioManager.instance.isInitialized && AudioManager.instance.tickSource != null) {
          SoLoud.instance.play(AudioManager.instance.tickSource!);
        }

        // --- START MATCH MUSIC ---
        if (AudioManager.instance.isInitialized) {
          AudioManager.instance.playRandomInGameTrack();
        }
        
        overlays.remove('countdown');
        overlays.add('countdown');
      }

      if (countdownTimer <= 0) {
        matchPhase = 'playing';
        gameStarted = true;
        overlays.remove('countdown');
        gameTimer.start(); 
        if (AudioManager.instance.isInitialized && AudioManager.instance.impactSource != null) {
          SoLoud.instance.play(AudioManager.instance.impactSource!);
        }
      }
      return; 
    }

    if (!gameStarted) return;

    if (AudioManager.instance.isInitialized) {
      const double audioScale = 50.0; 
      final pX = player.position.x / audioScale;
      final pY = player.position.y / audioScale;
      SoLoud.instance.set3dListenerPosition(pX, pY, 0.0);
      
      final forwardX = -sin(player.angle);
      final forwardY = -cos(player.angle);
      SoLoud.instance.set3dListenerAt(forwardX, forwardY, 0.0);
      SoLoud.instance.set3dListenerUp(0.0, 0.0, -1.0);
    }

    if (isHost && bots.isNotEmpty) {
      hostBotSyncTick += dt;
      if (hostBotSyncTick >= hostBotSyncRate) {
        hostBotSyncTick = 0;
        List<Map<String, dynamic>> botData = [];
        for (var bot in bots) {
          // Send facingAngle instead of angle, and include 'i' for invisibility
          botData.add({'x': bot.position.x, 'y': bot.position.y, 'a': bot.facingAngle, 'i': bot.isInvisible});
        }
        myChannel.sendBroadcastMessage(event: 'sync_bots', payload: {'bots': botData});
      }
    }
  }

  @override
  void onRemove() {
    // STRICT GUARDRAIL: Only overwrite the gallery if this instance actually took photos!
    // This prevents aborted matchmaking lobbies or cinematic modes from wiping your history.
    if (matchPhotos.isNotEmpty) {
      lastMatchPhotos = List.from(matchPhotos);
    }
    
    myChannel.unsubscribe();
    try {
      Supabase.instance.client.rpc('leave_match', params: {'p_match_id': roomId});
    } catch (e) {}

    AudioManager.instance.stopMusic(); 
    AudioManager.instance.playMenuMusic(); 

    super.onRemove();
  }

  void _spawnWorldEntities() {
    if (bots.isNotEmpty) return; 
    if (matchMode == 'cinematic') return;
    
    List<Vector2> availableSpawns = gameMap.playerSpawns.isNotEmpty 
        ? List<Vector2>.from(gameMap.playerSpawns)
        : [Vector2(150, 150), Vector2(400, 400)];
        
    availableSpawns.shuffle();
    availableSpawns.removeWhere((spawn) => spawn.distanceTo(player.position) < 300.0);

    if (matchMode == 'casual') {
      final config = LevelManager.getConfigForLevel(myPlayerLevel);
      matchHasHunter = Random().nextDouble() < 0.70;
      hunterHasSpawned = false;

      for (int i = 0; i < config.botCount; i++) {
        Vector2 safeBotSpawn = gameMap.getSafeSpawnLocation(
          availableSpawns.isNotEmpty ? availableSpawns.removeAt(0) : Vector2(500, 500), 
          Vector2.all(32.0),
        );
        bots.add(
          BotPlayer(isHunter: false)
            ..position = safeBotSpawn
            ..wanderSpeed = config.wanderSpeed
            ..huntSpeed = config.huntSpeed,
        );
      }
      for (var b in bots) world.add(b);

    } else {
      matchHasHunter = false;
      playerTeams[mySessionId] = 1; 
      if (matchMode == '2v2') player.applyTeamColor(1);

      int nextTeam = matchMode == '2v2' ? 2 : 0; 
      
      for (var remoteId in networkPlayers.keys) {
        playerTeams[remoteId] = nextTeam;
        if (matchMode == '2v2') {
          networkPlayers[remoteId]?.applyTeamColor(nextTeam);
          nextTeam = (nextTeam == 1) ? 2 : 1;
        }
      }

      int missingPlayers = targetPlayers - (1 + networkPlayers.length);
      
      for (int i = 0; i < missingPlayers; i++) {
        if (availableSpawns.isEmpty) break;
        Vector2 safeSpawn = gameMap.getSafeSpawnLocation(availableSpawns.removeAt(0), Vector2.all(32.0));
        
        final fakeHuman = BotPlayer(isHunter: false)
          ..position = safeSpawn
          ..wanderSpeed = 100.0 
          ..huntSpeed = 160.0
          ..teamId = (matchMode == '2v2') ? nextTeam : 0
          ..isCompetitiveStandIn = true;
          
        bots.add(fakeHuman);
        world.add(fakeHuman);

        if (matchMode == '2v2') nextTeam = (nextTeam == 1) ? 2 : 1; 
      }

      // --- NEW: FRIGHT NIGHT CHAOS MODIFIERS ---
      if (matchMode == 'fright_night' && chaosModifier == 'swarm') {
        List<Map<String, dynamic>> swarmData = [];
        int baseSeed = roomId.hashCode; // A shared, consistent seed!
        
        for (int i = 0; i < 25; i++) {
          if (availableSpawns.isEmpty) break;
          Vector2 spawnPos = gameMap.getSafeSpawnLocation(
            availableSpawns[Random().nextInt(availableSpawns.length)], 
            Vector2.all(16.0)
          );
          
          double startAngle = Random().nextDouble() * pi * 2;
          
          swarmData.add({
            'x': spawnPos.x,
            'y': spawnPos.y,
            'seed': baseSeed + i,
            'angle': startAngle
          });
          
          // Host spawns locally
          scareManager.spawnCritter(Critter(
            position: spawnPos, behavior: SwarmBehavior.scatter, 
            seed: baseSeed + i, index: i, initialAngle: startAngle, ownerId: 'server_swarm'
          ));
        }
        
        // Blast the spawn instructions to the clients ONCE. Zero traffic after this!
        myChannel.sendBroadcastMessage(event: 'spawn_swarm', payload: {'swarm': swarmData});
      }
      // -----------------------------------------

    }

    final random = Random();
    for (int i = 0; i < 4; i++) {
      double x = (random.nextDouble() * 2400) - 1200;
      double y = (random.nextDouble() * 2400) - 1200;
      if (!gameMap.checkCollision(Vector2(x,y), Vector2.all(16))) {
        world.add(PowerUp(id: 'spark_$i', position: Vector2(x, y)));
      }
    }

    if (!isGuildScrimmage && gameMap.potentialBoxSpawns.isNotEmpty) {
      List<Vector2> boxNodes = gameMap.potentialBoxSpawns.isNotEmpty 
          ? List.from(gameMap.potentialBoxSpawns)
          : [Vector2(400, 400), Vector2(800, 800), Vector2(1200, 1200), Vector2(1600, 1600)];

      boxNodes.shuffle();
      int boxesToSpawn = min(8, boxNodes.length);
      List<Map<String, dynamic>> boxPayload = [];

      for (int i = 0; i < boxesToSpawn; i++) {
        String boxId = 'spooky_box_${DateTime.now().millisecondsSinceEpoch}_$i';
        Vector2 pos = boxNodes[i];
        world.add(SpookyBox(id: boxId, position: pos));
        boxPayload.add({'id': boxId, 'x': pos.x, 'y': pos.y});
      }

      myChannel.sendBroadcastMessage(event: 'spawn_boxes', payload: {'boxes': boxPayload});
    }
  }

  Future<void> endGame() async {
    gameStarted = false; 

    // --- STOP MUSIC FOR SCORE SCREEN ---
    if (AudioManager.instance.isInitialized) {
      AudioManager.instance.stopPhysiologyLoops();
      
      // Explicitly kill the local player's breathing loop!
      player.stopAudio();
      
      // NEW: Force-kill all Bot and RemotePlayer audio loops bleeding into the lobby
      try {
        for (var child in world.children) {
          if (child is BotPlayer) (child as dynamic).stopAudio();
          if (child is RemotePlayer) (child as dynamic).stopAudio();
        }
      } catch (e) {
         debugPrint('Failed to stop remote audio: $e');
      }
      
      AudioManager.instance.stopMusic();
    }

    // ==========================================
    // JUGGERNAUT SCORE POOLING
    // ==========================================
    if (isGunner || hasGunner) {
      RemotePlayer? partner;
      
      if (isGunner && driverId != null) {
        // The Gunner already knows exactly who their Driver is
        partner = networkPlayers[driverId];
      } else if (hasGunner) {
        // The Driver finds their Gunner by looking for the player riding on their back
        for (var remote in networkPlayers.values) {
          if (remote.position.distanceTo(player.position) < 50.0) {
            partner = remote;
            break;
          }
        }
      }

      if (partner != null) {
        // Merge the combat points (Gunner) and the navigation loot (Driver)
        int combinedScore = player.score + partner.score;
        
        // Assign the massive pooled score to both players
        player.score = combinedScore;
        partner.score = combinedScore;
        
        // Optional: Fire a UI popup so they know their scores merged
        camera.viewport.add(FloatingText(
          text: 'SQUAD SCORE MERGED!', 
          worldPosition: Vector2(player.position.x - 50, player.position.y - 80)
        ));
      }
    }
    // ==========================================

    overlays.add('summary');
    
    // --- 1. CALCULATE LUMEN PLACEMENT ---
    List<int> allScores = [player.score];
    networkPlayers.forEach((id, remote) => allScores.add(remote.score));
    allScores.sort((a, b) => b.compareTo(a)); 
    
    int highestScore = allScores.first;
    bool isTie = allScores.where((s) => s == highestScore).length > 1;
    
    int baseStake = 27 + Random().nextInt(16); // Random win between 27 and 42

    // --- NEW: The "Participation" Threshold ---
    if (player.score == 0) {
      // You did nothing. You lose Lumen, no free rides!
      matchLumenDelta = -(baseStake - 2); 
    } else if (player.score == highestScore) {
      matchLumenDelta = isTie ? 2 : baseStake;
    } else {
      matchLumenDelta = -(baseStake - 2); // Lose 2 points less than the win value
    }

    // --- 2. EXISTING TEAM SCORING LOGIC ---
    int myTeamScore = player.score;
    int enemyTeamScore = 0;
    
    if (matchMode == '2v2') {
      int myTeamId = getEntityTeam(player);

      for (var bot in bots) {
        if (getEntityTeam(bot) == myTeamId) myTeamScore += bot.simulatedScore;
        else enemyTeamScore += bot.simulatedScore;
      }
      for (var entry in networkPlayers.entries) {
        if (getEntityTeam(entry.key) == myTeamId) myTeamScore += entry.value.score;
        else enemyTeamScore += entry.value.score;
      }

      if (myTeamScore > enemyTeamScore) {
        player.score += 1500; 
        camera.viewport.add(FloatingText(
          text: 'VICTORY BONUS! +1500', 
          worldPosition: Vector2(player.position.x - 40, player.position.y - 80)
        ));
        // If playing squads, winning the match overrides individual placements for Lumen
        matchLumenDelta = baseStake; 
      } else if (myTeamScore < enemyTeamScore) {
        matchLumenDelta = -(baseStake - 2);
      } else {
        matchLumenDelta = 2; // Tie
      }
    }

    if (!isGuildScrimmage) {
      int xpEarned = (player.score * 0.1).toInt();
      int shadowsEarned = (player.score * 0.05).toInt();
      
      // NEW: THE LOSER TAX
      // If you lose Lumen (a defeat), your coin payout is wiped out completely.
      // We grant a tiny pity payout of 10 Shadows.
      int finalCoins = player.coinsEarned;
      if (matchLumenDelta < 0) {
         finalCoins = 0;
         shadowsEarned = 10;
      }

      // --- THE ROOKIE BOOST ---
      // Guarantees massive progression for brand new players to hook them immediately
      if (myPlayerLevel < 3) {
        xpEarned *= 3; 
        shadowsEarned += 2500; 
        finalCoins += 50; 
        
        camera.viewport.add(FloatingText(
          text: 'ROOKIE BONUS APPLIED!', 
          worldPosition: Vector2(player.position.x - 50, player.position.y - 100)
        ));
      }

      // --- 3. SEND LUMEN TO DATABASE ---
      if (player.score > 0 || player.coinsEarned > 0 || matchLumenDelta != 0 || myPlayerLevel < 3) {
        try {
          await Supabase.instance.client.rpc(
            'process_match_rewards',
            params: {
              'xp_earned': xpEarned, 
              'shadows_earned': shadowsEarned, 
              'coins_earned': finalCoins,
              'p_lumen_delta': matchLumenDelta, 
            },
          );
        } catch (e) {
          debugPrint('Reward error: $e');
        }
        // --- SEND TACTICAL TELEMETRY ---
        try {
          await Supabase.instance.client.from('player_tactics_log').insert({
            'user_id': Supabase.instance.client.auth.currentUser!.id,
            'match_id': roomId,
            'scares_attempted': player.scaresAttempted,
            'scares_landed': player.scaresLanded, 
            'time_zero_energy': player.timeZeroEnergy,
            'times_stunned_standard': player.timesStunnedStandard,
            'times_charmed_siren': player.timesCharmedSiren,
            'times_hit_swarm': player.timesHitSwarm,
            'distance_sprinted': player.distanceSprinted,
            'distance_sneaked': player.distanceSneaked,
          });
        } catch (e) {
          debugPrint('Telemetry logging error: $e');
        }
      }
    }

    if (player.score > 0) {
      try {
        final userId = Supabase.instance.client.auth.currentUser?.id;
        if (userId != null) {
          final member = await Supabase.instance.client
              .from('guild_members')
              .select('guild_id')
              .eq('user_id', userId)
              .maybeSingle();

          if (member != null) {
            final activeNode = await Supabase.instance.client
                .from('guild_nodes')
                .select('id')
                .limit(1)
                .maybeSingle();

            if (activeNode != null) {
              await Supabase.instance.client.rpc('award_match_ip', params: {
                'p_user_id': userId,
                'p_guild_id': member['guild_id'],
                'p_node_id': activeNode['id'],
                'p_match_type': matchMode,
              });
            }
          }
        }
      } catch (e) {
        debugPrint('Guild IP award error: $e');
      }
    }

    if (isHost) {
      try {
        await Supabase.instance.client.from('active_matches').update({'status': 'ended'}).eq('id', roomId);
      } catch (e) {}
      
      myChannel.sendBroadcastMessage(event: 'match_control', payload: {'action': 'end'});

      if (isGuildScrimmage && scrimmageMessageId != null) {
        try {
          String _short(String id) => id.length >= 4 ? id.substring(0, 4) : id;
          
          Map<String, int> finalResults = {
            'Player ${_short(mySessionId)}': player.score,
          };
          networkPlayers.forEach((id, rp) {
            finalResults['Player ${_short(id)}'] = rp.score;
          });

          final msgRes = await Supabase.instance.client
              .from('guild_messages')
              .select('metadata')
              .eq('id', scrimmageMessageId!)
              .maybeSingle();

          if (msgRes != null) {
            Map<String, dynamic> meta = Map<String, dynamic>.from(msgRes['metadata'] ?? {});
            meta['status'] = 'finished';
            meta['results'] = finalResults;

            await Supabase.instance.client
                .from('guild_messages')
                .update({'metadata': meta})
                .eq('id', scrimmageMessageId!);
          }
        } catch (e) {
          debugPrint('Failed to post scrimmage results to chat: $e');
        }
      }
      // --- NEW: FRIGHT NIGHT SCOREBOARD & HIGHLIGHT REEL ---
      if (matchMode == 'fright_night' && myGuildId != null) {
        try {
          String _short(String id) => id.length >= 4 ? id.substring(0, 4) : id;
          
          Map<String, int> finalResults = {
            'Host (You)': player.score,
          };
          networkPlayers.forEach((id, rp) {
            finalResults['Player ${_short(id)}'] = rp.score;
          });

          var sortedEntries = finalResults.entries.toList()
            ..sort((a, b) => b.value.compareTo(a.value));
          Map<String, int> sortedResults = Map.fromEntries(sortedEntries);

          Map<String, dynamic>? highlightMeta;
          if (matchPhotos.isNotEmpty) {
            final snapshot = matchPhotos[Random().nextInt(matchPhotos.length)];
            highlightMeta = {
              'attacker': snapshot.attackerName,
              'victim': snapshot.victimName,
              'mask_id': snapshot.attackerMaskId,
              'time': snapshot.timestamp,
            };
          }

          await Supabase.instance.client.from('guild_messages').insert({
            'guild_id': myGuildId,
            'sender_id': Supabase.instance.client.auth.currentUser!.id,
            'message': 'The bloodbath has concluded.',
            'metadata': {
              'type': 'fright_night_results', // <-- Moved inside metadata!
              'results': sortedResults,
              'highlight': highlightMeta, 
            }
          });
        } catch (e) {
          debugPrint('Failed to post Fright Night results to chat: $e');
        }
      }
    }

    /* if (!isGuildScrimmage && buildContext != null) {
      VesselOpenerOverlay.show(buildContext!, 'shadow_reliquary');
    } */
  }

  void claimSpookyBox(String boxId) {
    myChannel.sendBroadcastMessage(event: 'claim_box', payload: {'player_id': mySessionId, 'box_id': boxId});
    _executeBoxClaim(boxId, mySessionId);
  }

  void _executeBoxClaim(String boxId, String playerId) {
    final boxes = world.children.whereType<SpookyBox>().where((b) => b.id == boxId).toList();
    if (boxes.isEmpty) return;

    final boxPos = boxes.first.position.clone();
    for (var box in boxes) box.removeFromParent();

    if (AudioManager.instance.isInitialized && AudioManager.instance.powerupSource != null) {
      SoLoud.instance.play(AudioManager.instance.powerupSource!);
    }

    if (playerId == mySessionId) {
      // Keep the original weighted base pool, but drastically nerf the SOULS (Score) payouts
      List<ChestReward> rewards = [
        ChestReward(type: ChestRewardType.points, label: '+50 SOULS', value: 50),
        ChestReward(type: ChestRewardType.points, label: '+50 SOULS', value: 50),
        ChestReward(type: ChestRewardType.points, label: '+50 SOULS', value: 50),
        ChestReward(type: ChestRewardType.points, label: '+100 SOULS', value: 100),
        ChestReward(type: ChestRewardType.points, label: '+100 SOULS', value: 100),
        ChestReward(type: ChestRewardType.invisibility, label: 'INVISIBILITY!'),
        ChestReward(type: ChestRewardType.invisibility, label: 'INVISIBILITY!'),
        ChestReward(type: ChestRewardType.teleport, label: 'TELEPORTED!'),
        ChestReward(type: ChestRewardType.teleport, label: 'TELEPORTED!'),
        ChestReward(type: ChestRewardType.rangeIncrease, label: 'RANGE EXTENDED!'),
        ChestReward(type: ChestRewardType.rangeIncrease, label: 'RANGE EXTENDED!'),
        ChestReward(type: ChestRewardType.disguise, label: 'DISGUISE!'), // Stays rare!
      ];

      // New players get a slightly better chance to pull hard currency to hook them
      if (myPlayerLevel < 4) {
        rewards.addAll([
          ChestReward(type: ChestRewardType.currency, label: '+3 COINS', value: 3),
          ChestReward(type: ChestRewardType.currency, label: '+3 COINS', value: 3),
          ChestReward(type: ChestRewardType.currency, label: '+5 COINS', value: 5),
          ChestReward(type: ChestRewardType.currency, label: '+5 COINS', value: 5),
        ]);
      } else {
        // Punishing economy for veterans (1 or 2 coins MAX)
        rewards.addAll([
          ChestReward(type: ChestRewardType.currency, label: '+1 COIN', value: 1),
          ChestReward(type: ChestRewardType.currency, label: '+1 COIN', value: 1),
          ChestReward(type: ChestRewardType.currency, label: '+2 COINS', value: 2),
        ]);
      }

      final selectedReward = rewards[Random().nextInt(rewards.length)];
      player.applyChestReward(selectedReward);
      camera.viewport.add(FloatingText(text: selectedReward.label, worldPosition: Vector2(boxPos.x - 20, boxPos.y - 40)));
    }
  }

  // --- NEW: Allow Competitive Bots to Loot (Nerfed to match player economy) ---
  void claimSpookyBoxForBot(String boxId, BotPlayer bot) {
    final boxes = world.children.whereType<SpookyBox>().where((b) => b.id == boxId).toList();
    if (boxes.isEmpty) return;

    final boxPos = boxes.first.position.clone();
    for (var box in boxes) box.removeFromParent();

    myChannel.sendBroadcastMessage(event: 'claim_box', payload: {'player_id': 'bot_${bots.indexOf(bot)}', 'box_id': boxId});

    if (AudioManager.instance.isInitialized && AudioManager.instance.powerupSource != null) {
      SoLoud.instance.play(AudioManager.instance.powerupSource!);
    }

    bot.simulatedScore += 75; // Nerfed from 300 to keep it balanced with players
    camera.viewport.add(FloatingText(text: '+75 SOULS', worldPosition: Vector2(boxPos.x - 20, boxPos.y - 40)));
  }
  
  int triggerLocalScare(Vector2 attackerPos, double attackerAngle, bool isPoweredUp, {bool hasExtendedRange = false, double range = 250.0, required String maskId}) {
    int hitCount = 0;
    final forward = Vector2(sin(attackerAngle), -cos(attackerAngle));
    
    // --- DYNAMIC RADIUS ASSIGNMENT ---
    double scareRadius = range;
    if (hasExtendedRange) scareRadius = 600.0;
    if (maskId == 'siren') scareRadius = 2000.0;
    if (maskId == 'gorgon') scareRadius = 1200.0; // Massive room-wide blast
    if (maskId == 'banshee') scareRadius = 1500.0; // Extreme sniper range

    for (var bot in bots) {
      if (bot.isHunter) bot.hearLoudNoise(attackerPos);
    }

    // ==========================================
    // 1. BOT COLLISION LOOP
    // ==========================================
    for (var bot in bots) {
      if (matchMode == '2v2' && getEntityTeam(player) == getEntityTeam(bot)) continue; 
      if (bot.localImmunityToMe > 0) continue; 
      
      String vSpecies = bot.species ?? 'humanoid';
      bool isPrey = _isFavoredPrey(player.species, vSpecies);
      double effectiveRadius = scareRadius * (isPrey ? 1.15 : 1.0);

      final toBot = bot.position - attackerPos;
      if (toBot.length < effectiveRadius) {
        toBot.normalize();
        final dot = forward.dot(toBot);

        if (maskId == 'siren') {
          if (dot > 0.0) { 
            bot.applyCharm(15.0, player);
            bot.localImmunityToMe = 16.0;
            hitCount++;
            player.scaresLanded++;
          }
        } 
        else {
          // --- MASK-SPECIFIC RAYCAST RULES - now checking an 
          //     expanding angle to checking their absolute 
          //     perpendicular distance from your banshee ---
          bool isHit = false;
          
          if (maskId == 'banshee') {
             // Banshee fires a fixed-width laser cylinder, ignoring walls
             final rawVector = bot.position - attackerPos;
             final proj = rawVector.dot(forward); // Distance along the laser
             if (proj > 0) { 
               final perpDist = (rawVector - (forward * proj)).length; // Distance from center of laser
               if (perpDist < 128.0) isHit = true; // 256px wide total corridor
             }
          } else {
             // Standard masks use expanding vision cones and check for walls
             final coneThreshold = isPoweredUp ? -0.2 : 0.1;
             bool hasLOS = gameMap.hasLineOfSight(bot.position, attackerPos);
             if (dot > coneThreshold && hasLOS) isHit = true;
          }
          
          // Gorgon requires the victim to be facing the attacker
          bool isLookingAtAttacker = true;
          if (maskId == 'gorgon') {
             final botForward = Vector2(sin(bot.facingAngle), -cos(bot.facingAngle));
             final botToAttacker = (attackerPos - bot.position).normalized();
             isLookingAtAttacker = botForward.dot(botToAttacker) > 0.2; // They must be facing you
          }

          if (isHit && isLookingAtAttacker) {
            if (bot.isHunter) {
              if (bot.isCoreExposed) {
                bot.applyStun(8.0); bot.localImmunityToMe = 10.0; 
                hitCount++;
                player.scaresLanded++;                
                player.score += 2500; 
                camera.viewport.add(FloatingText(text: 'CRITICAL OVERLOAD! +2500', worldPosition: Vector2(bot.position.x - 40, bot.position.y - 60)));
              } else {
                bot.applyStun(0.1); 
                camera.viewport.add(FloatingText(text: 'ARMOR DEFLECTED!', worldPosition: Vector2(bot.position.x - 20, bot.position.y - 40)));
              }
            } else {
              double stunDuration = _matchesDoctrine(bot) ? 4.4 : 4.0;
              if (isPrey) stunDuration *= 1.15; 
              
              // --- PARASITE VAMPIRISM ---
              if (maskId == 'parasite') {
                stunDuration = 1.5; // Very short stun
                player.flashlightBattery = (player.flashlightBattery + 25.0).clamp(0.0, 100.0);
                player.energy = (player.energy + 3.0).clamp(0.0, player.maxEnergy);
              }
              
              bot.applyStun(stunDuration); bot.localImmunityToMe = 7.0; bot.triggerPrivateHighlight(); hitCount++;

              logScareSnapshot(ScareSnapshot(
                attackerName: player.score > 0 ? 'You' : 'Attacker', 
                attackerCharId: player.equippedCharacterId, attackerMaskId: maskId,
                victimName: bot.fakeUsername, victimCharId: bot.assignedCharacterId,
                victimMaskId: bot.currentMaskId,
                timestamp: gameTimer.timeLeft.toInt(), mapX: attackerPos.x, mapY: attackerPos.y,
              ), isHuman: false);

              camera.viewport.add(FloatingText(text: '+100 SOULS', worldPosition: Vector2(bot.position.x - 25, bot.position.y - 60)));
            }
          }
        }
      }
    }

    // ==========================================
    // 2. REMOTE PLAYER COLLISION LOOP
    // ==========================================
    for (var remoteId in networkPlayers.keys) {
      if (matchMode == '2v2' && getEntityTeam(player) == getEntityTeam(remoteId)) continue; 
      
      var remotePlayer = networkPlayers[remoteId]!;
      if (remotePlayer.localImmunityToMe > 0) continue; 
      
      String vSpecies = 'humanoid';
      try { vSpecies = remotePlayer.species; } catch (_) {}
      bool isPrey = _isFavoredPrey(player.species, vSpecies);

      double effectiveRadius = scareRadius * (isPrey ? 1.15 : 1.0);
      
      final toPlayer = remotePlayer.position - attackerPos;
      if (toPlayer.length < effectiveRadius) {
        toPlayer.normalize();
        final dot = forward.dot(toPlayer);

        if (maskId == 'siren') {
          if (dot > 0.0) {
            remotePlayer.localImmunityToMe = 16.0; hitCount++;
            myChannel.sendBroadcastMessage(event: 'charm', payload: {'id': remoteId, 'duration': 15.0, 'charmer_x': attackerPos.x, 'charmer_y': attackerPos.y});
          }
        } else {
          // --- MASK-SPECIFIC RAYCAST RULES ---
          bool isHit = false;
          
          if (maskId == 'banshee') {
             // Banshee fires a fixed-width laser cylinder, ignoring walls
             final rawVector = remotePlayer.position - attackerPos;
             final proj = rawVector.dot(forward); // Distance along the laser
             if (proj > 0) { 
               final perpDist = (rawVector - (forward * proj)).length; // Distance from center of laser
               if (perpDist < 128.0) isHit = true; // <-- DOUBLED: 256px wide total corridor
             }
          } else {
             // Standard masks use expanding vision cones and check for walls
             final coneThreshold = isPoweredUp ? -0.2 : 0.1;
             bool hasLOS = gameMap.hasLineOfSight(remotePlayer.position, attackerPos);
             if (dot > coneThreshold && hasLOS) isHit = true;
          }
          
          bool isLookingAtAttacker = true;
          if (maskId == 'gorgon') {
             final rpForward = Vector2(sin(remotePlayer.facingAngle), -cos(remotePlayer.facingAngle));
             final rpToAttacker = (attackerPos - remotePlayer.position).normalized();
             isLookingAtAttacker = rpForward.dot(rpToAttacker) > 0.2; 
          }

          // FIX: Now we just check the isHit boolean!
          if (isHit && isLookingAtAttacker) {
            hitCount++;
            player.scaresLanded++;
            remotePlayer.localImmunityToMe = 5.0; 
            remotePlayer.triggerPrivateHighlight(); 
            
            double stunDuration = _matchesDoctrine(remotePlayer) ? 2.2 : 2.0;
            if (isPrey) stunDuration *= 1.15;
            
            // --- PARASITE VAMPIRISM ---
            if (maskId == 'parasite') {
              stunDuration = 1.5; 
              player.flashlightBattery = (player.flashlightBattery + 25.0).clamp(0.0, 100.0);
              player.energy = (player.energy + 3.0).clamp(0.0, player.maxEnergy);
            }

            myChannel.sendBroadcastMessage(event: 'stun', payload: {
              'id': remoteId, 'duration': stunDuration, 
              'attacker_id': mySessionId, 'attacker_x': attackerPos.x, 'attacker_y': attackerPos.y,
              'mask_id': maskId // <-- Pass the mask ID so the victim knows to drain their own battery!
            });

            logScareSnapshot(ScareSnapshot(
              attackerName: 'You', attackerCharId: player.equippedCharacterId, attackerMaskId: maskId,
              victimName: remoteId.substring(0, 4), victimCharId: remotePlayer.equippedCharacterId,
              victimMaskId: remotePlayer.currentMaskId,
              victimId: remoteId, timestamp: gameTimer.timeLeft.toInt(), mapX: attackerPos.x, mapY: attackerPos.y,
            ), isHuman: true);

            camera.viewport.add(FloatingText(text: '+100 SOULS', worldPosition: Vector2(remotePlayer.position.x - 25, remotePlayer.position.y - 60)));
          }
        }
      }
    }
    if (hitCount > 0) player.triggerPrivateHighlight();
    return hitCount;
  }
  
  void triggerLocalStart() {
    gameStarted = true;
    gameTimer.start();
    camera.viewport.children.whereType<StartButton>().toList().forEach((btn) => btn.removeFromParent());
    // --- START MATCH MUSIC ---
    if (AudioManager.instance.isInitialized) {
      AudioManager.instance.playRandomInGameTrack();
    }
  }

  void _setupSupabaseListener() {
    myChannel
      .onPresenceSync((payload) {
        final presenceState = myChannel.presenceState();
        List<Map<String, dynamic>> allUsers = [];
        for (final state in presenceState) {
          for (final presence in state.presences) {
            if (presence.payload != null && presence.payload.containsKey('id')) {
              allUsers.add({
                'id': presence.payload['id'], 
                'username': presence.payload['username'] ?? 'Player', // <-- Read incoming names
                'joined_at': presence.payload['joined_at']
              });
            }
          }
        }

        allUsers.sort((a, b) => (a['id'] as String).compareTo(b['id'] as String));

        if (allUsers.isNotEmpty && allUsers.first['id'] == mySessionId) {
          if (!isHost) {
            isHost = true;
            _spawnWorldEntities(); 
          }
          try {
            Supabase.instance.client.from('active_matches').update({'player_count': allUsers.length}).eq('id', roomId);
          } catch (e) {}
        } else {
          isHost = false;
        }

        for (var user in allUsers) {
          final id = user['id'] as String;
          if (id != mySessionId && !networkPlayers.containsKey(id)) {
            if (matchPhase != 'searching') continue; 
            
            final newPlayer = RemotePlayer()..position = Vector2(-100, -100);
            newPlayer.username = user['username'] as String; // <-- Assign it to the avatar
            networkPlayers[id] = newPlayer;
            world.add(newPlayer);
          }
        }

        final activeIds = allUsers.map((u) => u['id']).toSet();
        networkPlayers.keys.toList().forEach((id) {
          /* if (!activeIds.contains(id)) {
            networkPlayers[id]?.removeFromParent();
            networkPlayers.remove(id);
          } */
          // Protect the dummy from being deleted by the network sync!
          if (!activeIds.contains(id) && id != 'dummy_driver_123') {
            networkPlayers[id]?.removeFromParent();
            networkPlayers.remove(id);
          }
        });
      })
      .onBroadcast(
        event: 'spawn_swarm',
        callback: (payload) {
          if (!isHost) {
            final swarmList = payload['swarm'] as List<dynamic>;
            for (int i = 0; i < swarmList.length; i++) {
              final data = swarmList[i];
              scareManager.spawnCritter(Critter(
                position: Vector2(data['x'] as double, data['y'] as double),
                behavior: SwarmBehavior.scatter,
                seed: data['seed'] as int,
                index: i,
                initialAngle: data['angle'] as double,
                ownerId: 'server_swarm'
              ));
            }
          }
        },
      )
      .onBroadcast(
        event: 'hunter_emerge',
        callback: (payload) {
          if (!isHost) {
            final index = payload['bot_index'] as int?;
            if (index != null && index >= 0 && index < bots.length) {
              bots[index].transformToHunter();
            }
          }
        },
      )
      .onBroadcast(
        event: 'bot_scare',
        callback: (payload) {
          if (!isHost) {
            final index = payload['bot_index'] as int;
            if (index >= 0 && index < bots.length) {
              final bot = bots[index];
              bot.currentMaskId = payload['mask_id'] as String;
              bot.position.x = payload['x'] as double;
              bot.position.y = payload['y'] as double;
              bot.facingAngle = payload['a'] as double;
              
              // FIXED: Prevent giant stuck animations from off-screen bots
              if (bot.position.distanceTo(player.position) < 1000.0) {
                if (bot.voxelComponent != null) bot.voxelComponent!.triggerScareAnimation(bot.currentMaskId);
              }

              AudioManager.instance.playSpatialScare(bot.currentMaskId, bot.position);
              
              if (bot.currentMaskId == 'flying') {
                world.add(FlyingScareBlast(position: bot.position.clone(), angle: bot.facingAngle, ownerId: 'bot_$index'));
              } else if (bot.currentMaskId == 'vermin') {
                for (int i = 0; i < 15; i++) {
                  scareManager.spawnCritter(Critter(position: bot.position.clone(), behavior: SwarmBehavior.scatter, seed: DateTime.now().millisecondsSinceEpoch, index: i, initialAngle: bot.facingAngle, ownerId: 'bot_$index'));
                }
              } else if (bot.currentMaskId == 'siren') {
                bot.add(SirenBlast()..position = bot.size / 2);
              } else if (bot.currentMaskId == 'banshee') {
                world.add(BansheeBeam(position: bot.position.clone(), angle: bot.facingAngle));
              } else {
                world.add(ScareBlast(position: bot.position.clone(), angle: bot.facingAngle - (pi / 2))..priority = bot.priority + 5);
              }
            }
          }
        },
      )
      .onBroadcast(
        event: 'quick_chat',
        callback: (payload) {
          final senderId = payload['id'] as String?;
          final text = payload['text'] as String;
          final colorValue = payload['color'] as int;
          
          if (senderId == null || senderId == mySessionId) return;

          // 1. Is it a Remote Player?
          if (networkPlayers.containsKey(senderId)) {
            final remote = networkPlayers[senderId]!;
            remote.add(ChatBubbleComponent(
              text: text, 
              borderColor: Color(colorValue),
            ));
            
            if (AudioManager.instance.isInitialized && AudioManager.instance.tickSource != null) {
              SoLoud.instance.play(AudioManager.instance.tickSource!, volume: 0.8);
            }
          } 
          // 2. Is it a Bot?
          else if (senderId.startsWith('bot_')) {
            int botIndex = int.tryParse(senderId.split('_')[1]) ?? -1;
            if (botIndex >= 0 && botIndex < bots.length) {
              bots[botIndex].add(ChatBubbleComponent(text: text, borderColor: Color(colorValue)));
              
              if (AudioManager.instance.isInitialized && AudioManager.instance.tickSource != null) {
                SoLoud.instance.play(AudioManager.instance.tickSource!, volume: 0.8);
              }
            }
          }
        },
      )
      .onBroadcast(
        event: 'wall_hit',
        callback: (payload) {
          final id = payload['id'] as String?;
          if (id != null && networkPlayers.containsKey(id)) {
            final remote = networkPlayers[id]!;
            remote.position.x = payload['x'] as double;
            remote.position.y = payload['y'] as double;
            remote.triggerPrivateHighlight();
            
            if (AudioManager.instance.isInitialized && AudioManager.instance.impactSource != null) {
              SoLoud.instance.play(AudioManager.instance.impactSource!, volume: 0.6);
            }
          }
        },
      )
      .onBroadcast(
        event: 'move',
        callback: (payload) {
          final id = payload['id'] as String?;
          if (id == null || id == mySessionId) return;
          if (id != mySessionId) {
            final x = payload['x'] as double;
            final y = payload['y'] as double;
            final angle = payload['a'] as double;
            final colorStr = payload['c'] as String?; 
            final newScore = payload['s'] as int?; 
            final isDisguised = payload['d'] as bool? ?? false;
            final isMoving = payload['m'] as bool? ?? false;
            final isInvisible = payload['i'] as bool? ?? false;
            final fScale = payload['f'] as double? ?? 1.0;
            final sp = payload['sp'] as String? ?? 'humanoid';

            final maskId = payload['mask_id'] as String? ?? 'standard';

            if (!networkPlayers.containsKey(id)) {
              if (matchPhase != 'searching') return; 
              
              final newPlayer = RemotePlayer()..position = Vector2(x, y);
              networkPlayers[id] = newPlayer;
              world.add(newPlayer);
            }

            networkPlayers[id]!.updatePosition(
              x, y, angle, 
              colorStr: colorStr, newScore: newScore,
              isDisguised: isDisguised, isMoving: isMoving, isInvisible: isInvisible,
              fScale: fScale,
              maskId: maskId,
              species: sp,
            );
          }
        },
      )
      .onBroadcast(
        event: 'global_blackout',
        callback: (payload) {
          isGlobalBlackout = payload['active'] as bool? ?? false;
        },
      )
      .onBroadcast(
        event: 'scare',
        callback: (payload) {
          final id = payload['id'] as String?;
          if (id == null || id == mySessionId || !networkPlayers.containsKey(id)) return;
          if (id != mySessionId && networkPlayers.containsKey(id)) {
            final remote = networkPlayers[id]!;
            remote.position.x = payload['x'] as double;
            remote.position.y = payload['y'] as double;
            remote.facingAngle = payload['a'] as double;
            
            final maskId = payload['mask_id'] as String? ?? 'standard'; 
            final seed = payload['seed'] as int? ?? 0;

            remote.currentMaskId = maskId;

            // FIXED: Prevent giant stuck animations from off-screen remote players
            if (remote.position.distanceTo(player.position) < 1000.0) {
              if (remote.voxelComponent != null) remote.voxelComponent!.triggerScareAnimation(maskId);
            }

            AudioManager.instance.playSpatialScare(maskId, remote.position);

            if (maskId == 'flying') {
              // --- Add directly to the world ---
              world.add(FlyingScareBlast(position: remote.position.clone(), angle: remote.facingAngle, ownerId: payload['id']));
            } else if (maskId == 'vermin') {
              for (int i = 0; i < 15; i++) { 
                scareManager.spawnCritter(Critter(
                  position: remote.position.clone(), behavior: SwarmBehavior.scatter,
                  seed: seed, index: i, initialAngle: remote.facingAngle, ownerId: id,
                ));
              }
            } else if (maskId == 'siren') {
              remote.add(SirenBlast()..position = remote.size / 2);
            } else if (maskId == 'banshee') {
                world.add(BansheeBeam(position: remote.position.clone(), angle: remote.facingAngle));
             } else {
              world.add(ScareBlast(position: remote.position.clone(), angle: remote.facingAngle - (pi / 2))..priority = remote.priority + 5);
            }

            if (isHost && maskId != 'flying' && maskId != 'vermin') {
              final forward = Vector2(sin(remote.facingAngle), -cos(remote.facingAngle));
              for (var bot in bots) {
                if (matchMode == '2v2' && getEntityTeam(id) == getEntityTeam(bot)) continue; 
                if (bot.localImmunityToMe > 0) continue; 
                
                final toBot = bot.position - remote.position;
                if (toBot.length < 250.0) {
                  toBot.normalize();
                  if (forward.dot(toBot) > 0.1 && gameMap.hasLineOfSight(bot.position, remote.position)) {
                    double stunDuration = _matchesDoctrine(bot) ? 4.4 : 4.0;
                    bot.applyStun(stunDuration); 
                    bot.localImmunityToMe = 7.0; 
                    bot.triggerPrivateHighlight(); 
                  }
                }
              }
            }
          }
        },
      )
      .onBroadcast(
        event: 'trap_detonate',
        callback: (payload) {
          final ownerId = payload['owner_id'] as String?;
          
          // Only render this if WE aren't the owner (since the owner already rendered it locally)
          if (ownerId != null && ownerId != mySessionId) {
            final trapX = (payload['x'] as num).toDouble();
            final trapY = (payload['y'] as num).toDouble();
            final trapAngle = (payload['a'] as num).toDouble();
            final trapPos = Vector2(trapX, trapY);

            // Spawn the visuals and audio for bystanders
            world.add(ScareBlast(position: trapPos.clone(), angle: trapAngle - (pi / 2))..priority = 1000);
            AudioManager.instance.playSpatialScare('standard', trapPos);
            
            camera.viewport.add(FloatingText(
              text: 'POLTERGEIST TRIGGERED!', 
              worldPosition: Vector2(trapX - 60, trapY - 60)
            ));
          }
        },
      )
      .onBroadcast(
        event: 'taunt',
        callback: (payload) {
          final id = payload['id'] as String?;
          if (id == null || id == mySessionId) return; // Don't echo your own taunt
          
          final tauntId = payload['taunt_id'] as String;
          final tauntPos = Vector2((payload['x'] as num).toDouble(), (payload['y'] as num).toDouble());

          AudioManager.instance.playSpatialTaunt(tauntId, tauntPos);

          if (networkPlayers.containsKey(id)) {
            camera.viewport.add(FloatingText(
              text: '*TAUNT*', 
              worldPosition: Vector2(tauntPos.x - 30, tauntPos.y - 60)
            ));
          }
        },
      )
      .onBroadcast(
        event: 'charm',
        callback: (payload) {
          final targetId = payload['id'] as String?;
          if (targetId == null) return;
          final duration = (payload['duration'] as num).toDouble();
          final charmerPos = Vector2((payload['charmer_x'] as num).toDouble(), (payload['charmer_y'] as num).toDouble());

          if (targetId == mySessionId) {
            player.applyCharm(duration, charmerPos);
          } 
        },
      )
      .onBroadcast(
        event: 'dissonance',
        callback: (payload) {
          final id = payload['id'] as String?;
          if (id == mySessionId) {
            final duration = (payload['duration'] as num?)?.toDouble() ?? 3.0;
            player.applyDissonance(duration);
          }
        },
      )
      .onBroadcast(
        event: 'stun',
        callback: (payload) {
          final targetId = payload['id'] as String?;
          if (targetId == null) return;
          final duration = (payload['duration'] as num).toDouble();
          final attackerId = payload['attacker_id'] as String?;
          final maskId = payload['mask_id'] as String? ?? 'standard'; // Check the weapon

          if (targetId == mySessionId) {
            jumpScareEffect.trigger();
            
            Vector2? atkPos;
            if (payload.containsKey('attacker_x') && payload.containsKey('attacker_y')) {
              atkPos = Vector2((payload['attacker_x'] as num).toDouble(), (payload['attacker_y'] as num).toDouble());
            }

            // --- THE PARASITE PENALTY ---
            if (maskId == 'parasite') {
              player.flashlightBattery = (player.flashlightBattery - 25.0).clamp(0.0, 100.0);
              player.energy = (player.energy - 3.0).clamp(0.0, player.maxEnergy);
              camera.viewport.add(FloatingText(text: 'VAMPIRIZED!', worldPosition: Vector2(player.position.x - 20, player.position.y - 40)));
            }

            player.applyStun(duration, attackerPos: atkPos);
            player.triggerPrivateHighlight();
            
            if (AudioManager.instance.isInitialized && AudioManager.instance.impactSource != null) {
              SoLoud.instance.play(AudioManager.instance.impactSource!);
            }
            
            if (attackerId != null && networkPlayers.containsKey(attackerId)) {
              networkPlayers[attackerId]!.triggerPrivateHighlight();
            }
          } else if (networkPlayers.containsKey(targetId)) {
            networkPlayers[targetId]!.applyStun(duration);
          }
        },
      )
      .onBroadcast(
        event: 'spawn_boxes',
        callback: (payload) {
          if (!isHost) {
            final boxList = payload['boxes'] as List<dynamic>;
            for (var data in boxList) {
              world.add(SpookyBox(id: data['id'] as String, position: Vector2(data['x'] as double, data['y'] as double)));
            }
          }
        },
      )
      .onBroadcast(
        event: 'start_countdown',
        callback: (payload) {
          if (!isHost && matchPhase == 'searching') {
            if (payload.containsKey('teams')) {
              final teamsData = payload['teams'] as Map<String, dynamic>;
              teamsData.forEach((key, value) {
                playerTeams[key] = value as int;
              });

              if (matchMode == '2v2') {
                int myTeam = playerTeams[mySessionId] ?? 1;
                player.applyTeamColor(myTeam);

                for (var remoteId in networkPlayers.keys) {
                  int remoteTeam = playerTeams[remoteId] ?? 0;
                  networkPlayers[remoteId]?.applyTeamColor(remoteTeam);
                }
              }
            }
            
            matchPhase = 'countdown';
            overlays.remove('searching');
            overlays.add('countdown');
          }
        },
      )
      .onBroadcast(
        event: 'claim_box',
        callback: (payload) => _executeBoxClaim(payload['box_id'] as String, payload['player_id'] as String),
      )
      .onBroadcast(
        event: 'match_control',
        callback: (payload) {
          final action = payload['action'] as String;
          if (action == 'start') triggerLocalStart(); else if (action == 'end') endGame();
        },
      )
      .onBroadcast(
        event: 'request_sync',
        callback: (payload) {
          if (isHost) myChannel.sendBroadcastMessage(event: 'sync_state', payload: {'gameStarted': gameStarted, 'timeLeft': gameTimer.timeLeft});
        },
      )
      .onBroadcast(
        event: 'sync_bots',
        callback: (payload) {
          if (!isHost) {
            final botList = payload['bots'] as List<dynamic>;
            for (int i = 0; i < botList.length; i++) {
              final data = botList[i] as Map<String, dynamic>;
              while (bots.length <= i) {
                final dummyBot = BotPlayer()..position = Vector2(-1000, -1000);
                bots.add(dummyBot);
                world.add(dummyBot);
              }
              bots[i].position.x = data['x'] as double;
              bots[i].position.y = data['y'] as double;
              // Ensure we write to facingAngle and decode 'i'
              bots[i].facingAngle = data['a'] as double;
              bots[i].isInvisible = data['i'] as bool? ?? false;
            }
          }
        },
      )
      .onBroadcast(
        event: 'sync_state',
        callback: (payload) {
          if (!isHost) {
            final isRunning = payload['gameStarted'] as bool;
            final time = (payload['timeLeft'] as num).toDouble();
            
            gameTimer.timeLeft = time; 
            // --- NEW: Sync the absolute clock to match the host ---
            gameTimer.matchEndTime = DateTime.now().add(Duration(milliseconds: (time * 1000).toInt()));
            
            if (isRunning && !gameStarted) {
              triggerLocalStart();
            } else if (!isRunning && gameStarted) {
              endGame();
            }
          }
        },
      )
      .onBroadcast(
        event: 'consume_powerup',
        callback: (payload) {
          final id = payload['id'] as String;
          world.children.whereType<PowerUp>().where((p) => p.id == id).toList().forEach((p) => p.removeFromParent());
        },
      )
      .subscribe((status, [error]) async {
        if (status == RealtimeSubscribeStatus.subscribed) {
          // Add your username to the tracking payload!
          await myChannel.track({'id': mySessionId, 'username': myUsername, 'joined_at': DateTime.now().toUtc().toIso8601String()});
          myChannel.sendBroadcastMessage(event: 'request_sync', payload: {});
        }
      });
  }

  // Just-In-Time Asset Loader
  static Future<void> ensureCharacterLoaded(String charId) async {
    if (charId == 'default' || characterImagesCache.containsKey(charId)) return;

    try {
      final charRes = await Supabase.instance.client
          .from('characters').select('zip_asset_path').eq('id', charId).eq('enabled', true).maybeSingle();
      
      if (charRes == null || charRes['zip_asset_path'] == null) return;
      
      String zipPath = charRes['zip_asset_path'];
      
      // FIX: Strip the accidental double prefix if it exists in the database
      if (zipPath.startsWith('assets/assets/')) {
        zipPath = zipPath.replaceFirst('assets/assets/', 'assets/');
      }

      List<int> bytes = await CharacterAssetManager.getZipBytes(zipPath);
      final archive = ZipDecoder().decodeBytes(bytes);
      
      Map<String, ui.Image> images = {};
      Map<String, dynamic>? rig;

      for (final file in archive) {
        if (file.isFile) {
          if (file.name == 'rig.json') {
            rig = jsonDecode(utf8.decode(file.content as List<int>));
          } else if (file.name.endsWith('.png')) {
            final ui.Codec codec = await ui.instantiateImageCodec(file.content as Uint8List);
            final ui.FrameInfo frameInfo = await codec.getNextFrame();
            images[file.name] = frameInfo.image;
          }
        }
      }
      if (rig != null) {
        characterImagesCache[charId] = images;
        characterRigCache[charId] = rig;
      }
    } catch (e) {
      // Fails gracefully; engine will safely fallback to the default base mesh
      debugPrint('Lazy load bypassed for missing asset $charId: $e');
    }
  }
}