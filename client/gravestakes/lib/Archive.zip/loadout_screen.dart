import 'dart:convert';
import 'dart:math'; 
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;

import 'package:flutter/material.dart';
import 'package:flame/game.dart';
import 'package:flame/components.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

import 'package:showcaseview/showcaseview.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'voxel_character_component.dart';
import 'character_asset_manager.dart';

import 'tactical_analyzer.dart';

// --- DATA MODELS ---
class WearableDef {
  final String id;
  final String name;
  final String slotType;
  final String counterTarget;
  final String buffStat;
  final double buffValue;
  final bool isActiveDefense;
  final double energyCost;
  final int price;
  final String currency;
  final String? assetPath;

  WearableDef.fromJson(Map<String, dynamic> json)
      : id = json['id']?.toString() ?? 'unknown',
        name = json['name']?.toString() ?? 'Unknown',
        slotType = json['slot_type']?.toString() ?? 'unknown',
        counterTarget = json['counter_target']?.toString() ?? '',
        buffStat = json['buff_stat']?.toString() ?? '',
        buffValue = (json['buff_value'] as num?)?.toDouble() ?? 1.0,
        isActiveDefense = json['is_active_defense'] as bool? ?? false, 
        energyCost = (json['energy_cost'] as num?)?.toDouble() ?? 0.0,
        price = (json['price'] as num?)?.toInt() ?? 0,
        currency = json['currency']?.toString() ?? 'shadows',
        assetPath = json['asset_path']?.toString() ?? json['thumbnail_path']?.toString();
}

class LoadoutScreen extends StatefulWidget {
  const LoadoutScreen({super.key});

  @override
  State<LoadoutScreen> createState() => _LoadoutScreenState();
}

class _LoadoutScreenState extends State<LoadoutScreen> with SingleTickerProviderStateMixin {
  final supabase = Supabase.instance.client;

  late TabController _tabController;
  late MannequinGame _mannequinGame;

  // --- COMMITTED STATE (Database) ---
  String _committedCharacterId = 'default';
  Map<String, String> _committedLoadout = {};
  List<String> _committedMasks = ['', '', '', ''];

  // tutorial keys:
  final GlobalKey _maskSlotKey = GlobalKey();
  final GlobalKey _sealKey = GlobalKey();
  final GlobalKey _loadoutBackKey = GlobalKey();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final GlobalKey _masksTabKey = GlobalKey();
  final GlobalKey _inventoryMaskKey = GlobalKey();

  // --- DRAFT STATE (UI) ---
  String _draftCharacterId = 'default';
  String _previewCharacterId = 'default';
  Map<String, String> _draftLoadout = {};
  List<String> _draftMasks = ['', '', '', ''];

  // --- SELECTION STATE ---
  String? _selectedInventoryId;
  String? _selectedItemType;

  // --- DATA CACHES ---
  List<Map<String, dynamic>> _inventory = [];
  List<String> _ownedCharacters = ['default'];
  Map<String, int> _userShards = {};
  List<Map<String, dynamic>> _pendingRewards = []; // <-- NEW QUEUE TRACKER
  
  Map<String, WearableDef> _wearablesCatalog = {};
  Map<String, Map<String, dynamic>> _masksCatalog = {};
  Map<String, Map<String, dynamic>> _charactersCatalog = {}; 

  int _playerShadows = 0;
  int _playerCoins = 0;
  bool _isLoading = true;

  bool get _hasUnsavedChanges => 
      _draftCharacterId != _committedCharacterId ||
      !mapEquals(_committedLoadout, _draftLoadout) || 
      !listEquals(_committedMasks, _draftMasks);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 6, vsync: this); 
    _mannequinGame = MannequinGame();
    _fetchLoadoutData();
  }

  Future<void> _fetchLoadoutData() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final responses = await Future.wait<dynamic>([
        supabase.from('wallets').select('shadows, coins').eq('id', userId).single(), 
        supabase.from('wearables').select(),                                         
        supabase.from('masks').select().order('price'),                             
        supabase.from('characters').select().neq('enabled', false), 
        supabase.from('user_loadouts').select('slot_type, item_value').eq('user_id', userId), 
        supabase.from('user_inventory').select('item_id, item_type').eq('user_id', userId),   
        supabase.from('user_characters').select('character_id').eq('user_id', userId),
        supabase.from('user_shards').select('character_id, shard_count').eq('user_id', userId),
        supabase.from('pending_rewards').select('*').eq('user_id', userId).eq('is_claimed', false), // <-- FETCH REWARDS
      ]);

      final walletData = responses[0] as Map<String, dynamic>;
      _playerShadows = walletData['shadows'] ?? 0;
      _playerCoins = walletData['coins'] ?? 0;

      final wearablesRes = List<Map<String, dynamic>>.from(responses[1]);
      _wearablesCatalog.clear();
      for (var row in wearablesRes) {
        try {
          final w = WearableDef.fromJson(row);
          _wearablesCatalog[w.id] = w;
        } catch (e) {
          debugPrint('Skipping malformed wearable: $e');
        }
      }

      final masksRes = List<Map<String, dynamic>>.from(responses[2]);
      _masksCatalog.clear();
      for (var row in masksRes) {
        _masksCatalog[row['id']?.toString() ?? 'unknown'] = row;
      }

      final charactersRes = List<Map<String, dynamic>>.from(responses[3]);
      _charactersCatalog.clear();
      for (var row in charactersRes) {
        _charactersCatalog[row['id']?.toString() ?? 'unknown'] = row;
      }

      final loadoutRes = List<Map<String, dynamic>>.from(responses[4]);
      _committedCharacterId = 'default';
      _committedLoadout.clear();
      _committedMasks = ['', '', '', ''];

      for (var row in loadoutRes) {
        final slot = row['slot_type']?.toString() ?? '';
        final val = row['item_value']?.toString() ?? '';
        
        if (slot.isEmpty || val.isEmpty) continue;
        
        if (slot == 'character') {
          _committedCharacterId = val;
        } else if (slot.startsWith('mask_')) {
          int index = int.parse(slot.split('_')[1]) - 1;
          if (index >= 0 && index < 4) _committedMasks[index] = val;
        } else {
          _committedLoadout[slot] = val;
        }
      }

      _inventory = List<Map<String, dynamic>>.from(responses[5]);

      final userCharsRes = List<Map<String, dynamic>>.from(responses[6]);
      _ownedCharacters = userCharsRes.map((r) => r['character_id']?.toString() ?? 'unknown').toList();
      if (!_ownedCharacters.contains('default')) _ownedCharacters.add('default');

      final userShardsRes = List<Map<String, dynamic>>.from(responses[7]);
      _userShards.clear();
      for (var row in userShardsRes) {
        final charId = row['character_id']?.toString() ?? 'unknown';
        final shardCount = (row['shard_count'] as num?)?.toInt() ?? 0;
        _userShards[charId] = shardCount;
      }

      // Populate pending rewards
      _pendingRewards = List<Map<String, dynamic>>.from(responses[8]);

      _revertDraft(); 

      if (mounted) setState(() => _isLoading = false);
    } catch (e) {
      debugPrint('Crypt Fetch Error: $e');
      if (mounted) setState(() => _isLoading = false);
    }

    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString('tutorial_phase') == 'loadout') {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _scaffoldKey.currentContext != null) {
          ShowCaseWidget.of(_scaffoldKey.currentContext!).startShowCase([_masksTabKey]);
        }
      });
    }
  }

  // --- NEW: CLAIM RPC TRIGGER ---
  Future<void> _claimReward(String rewardId) async {
    try {
      final response = await supabase.rpc(
        'claim_pending_reward',
        params: {'p_reward_id': rewardId},
      );

      final status = response['status'];
      
      if (mounted) {
        if (status == 'duplicate_converted') {
          final comp = response['compensation'];
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Duplicate item converted into $comp Coins!', style: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
              backgroundColor: Colors.amber[900],
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Item added to your Crypt!', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
              backgroundColor: Colors.cyan,
            ),
          );
        }
        
        // Refresh the Crypt UI to remove the item from the queue and show it in the inventory
        setState(() => _isLoading = true);
        _fetchLoadoutData(); 
      }
    } catch (e) {
      debugPrint('Error claiming reward: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to claim reward. Please try again.', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  Future<void> _bindOperative(String charId, int cost, String name) async {
    if (_playerCoins < cost) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Not enough COINS to bind $name!', style: const TextStyle(fontFamily: 'Orbitron')), backgroundColor: Colors.red),
      );
      return;
    }
    setState(() => _isLoading = true);
    try {
      await supabase.rpc('bind_operative', params: {'p_character_id': charId});
      await _fetchLoadoutData(); 
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$name Evolved Successfully!', style: const TextStyle(fontFamily: 'Orbitron')), backgroundColor: Colors.greenAccent),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Binding failed: $e', style: const TextStyle(fontFamily: 'Orbitron')), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _buyItem(String itemType, String itemId, int price, String currency) async {
    final user = supabase.auth.currentUser;
    if (user == null) return;

    int currentBalance = currency == 'coins' ? _playerCoins : _playerShadows;
    if (currentBalance < price) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Not enough ${currency.toUpperCase()}!', style: const TextStyle(fontFamily: 'Orbitron')), backgroundColor: Colors.red),
      );
      return;
    }

    try {
      await supabase.rpc('buy_item', params: {
        'p_item_type': itemType,
        'p_item_id': itemId,
        'p_price': price,
        'p_currency': currency,
      });

      Sentry.addBreadcrumb(Breadcrumb(
        message: 'Purchased $itemId in Crypt for $price $currency',
        category: 'crypt_purchase',
      ));

      setState(() {
        if (currency == 'coins') {
          _playerCoins -= price;
        } else {
          _playerShadows -= price;
        }
        _inventory.add({'item_id': itemId, 'item_type': itemType});

        if (itemType == 'character') _ownedCharacters.add(itemId); 
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$itemId acquired!', style: const TextStyle(fontFamily: 'Orbitron')), backgroundColor: Colors.green),
      );

      _selectInventoryItem(itemType, itemId);
    } catch (e) {
      debugPrint('Crypt Purchase Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Purchase failed: $e', style: const TextStyle(fontFamily: 'Orbitron')), backgroundColor: Colors.red),
      );
    }
  }

  void _showPurchaseConfirm({
    required String itemType,
    required String itemId,
    required String name,
    required int price,
    required String currency,
  }) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: Text('Acquire $name?', style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
        content: Text(
          'Unlock this $itemType for $price ${currency.toUpperCase()}?',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('CANCEL', style: TextStyle(color: Colors.grey, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: currency == 'coins' ? Colors.amber[800] : Colors.red[800],
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              _buyItem(itemType, itemId, price, currency);
            },
            child: Text('BUY ($price ${currency.toUpperCase()})', style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _revertDraft() {
    setState(() {
      _draftCharacterId = _committedCharacterId;
      _previewCharacterId = _committedCharacterId;
      _draftLoadout = Map.from(_committedLoadout);
      _draftMasks = List.from(_committedMasks);
      _selectedInventoryId = null;
      _selectedItemType = null;
    });
    _mannequinGame.loadBaseCharacter(_draftCharacterId);
    if (_draftMasks[0].isNotEmpty) {
      _mannequinGame.setPreviewMask(_draftMasks[0]);
    } else {
      _mannequinGame.setPreviewMask(null);
    }
  }

  Future<void> _commitDraft() async {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    setState(() => _isLoading = true);

    try {
      final basePayloads = [
        {'user_id': userId, 'slot_type': 'character', 'item_value': _draftCharacterId}
      ];
      _draftLoadout.forEach((slot, val) {
        basePayloads.add({'user_id': userId, 'slot_type': slot, 'item_value': val});
      });

      for (int i = 0; i < 4; i++) {
        final maskVal = _draftMasks[i];
        if (maskVal.isNotEmpty) {
          basePayloads.add({'user_id': userId, 'slot_type': 'mask_${i + 1}', 'item_value': maskVal});
        } else {
          await supabase.from('user_loadouts')
              .delete().eq('user_id', userId).eq('slot_type', 'mask_${i + 1}');
        }
      }

      for (var payload in basePayloads) {
        await supabase.from('user_loadouts').upsert(payload, onConflict: 'user_id, slot_type');
      }

      setState(() {
        _committedCharacterId = _draftCharacterId;
        _previewCharacterId = _draftCharacterId;
        _committedLoadout = Map.from(_draftLoadout);
        _committedMasks = List.from(_draftMasks);
        _selectedInventoryId = null;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Commit Error: $e');
      setState(() => _isLoading = false);
    }
  }

  void _selectInventoryItem(String itemType, String itemId) async {
    setState(() {
      _selectedItemType = itemType;
      _selectedInventoryId = itemId;
    });

    if (itemType == 'character') {
      setState(() {
        _draftCharacterId = itemId;
        _previewCharacterId = itemId;
        _committedCharacterId = itemId; 
      });
      _mannequinGame.loadBaseCharacter(itemId);
      
      final userId = supabase.auth.currentUser?.id;
      if (userId != null) {
        try {
          await supabase.from('user_loadouts').upsert({
            'user_id': userId,
            'slot_type': 'character',
            'item_value': itemId
          }, onConflict: 'user_id, slot_type');
        } catch (e) {
          debugPrint('Failed to auto-save character selection: $e');
        }
      }
      
    } else if (itemType == 'mask') {
      _mannequinGame.setPreviewMask(itemId); 
    }
  }

  void _assignSelectedToSlot(String targetSlot) {
    if (_selectedInventoryId == null || _selectedItemType == null) return;

    setState(() {
      if (targetSlot.startsWith('mask_') && _selectedItemType == 'mask') {
        int index = int.parse(targetSlot.split('_')[1]) - 1;
        
        for (int i = 0; i < 4; i++) {
          if (_draftMasks[i] == _selectedInventoryId) {
            _draftMasks[i] = ''; 
          }
        }
        
        _draftMasks[index] = _selectedInventoryId!;
        _mannequinGame.setPreviewMask(_selectedInventoryId);
      } else if (_selectedItemType == targetSlot) {
        _draftLoadout[targetSlot] = _selectedInventoryId!;
        _mannequinGame.triggerEquipAnimation();
      }
    });
  }

  void _clearSlot(String targetSlot) {
    setState(() {
      if (targetSlot.startsWith('mask_')) {
        int index = int.parse(targetSlot.split('_')[1]) - 1;
        _draftMasks[index] = '';
        _mannequinGame.setPreviewMask(null);
      } else {
        _draftLoadout.remove(targetSlot);
      }
    });
  }

  double _getDraftStat(String buffStat, double baseValue) {
    double modifier = 1.0;
    _draftLoadout.forEach((slot, itemId) {
      if (_wearablesCatalog.containsKey(itemId) && _wearablesCatalog[itemId]!.buffStat == buffStat) {
        modifier *= _wearablesCatalog[itemId]!.buffValue;
      }
    });
    return baseValue * modifier;
  }

  Widget buildSafeItemThumbnail({required String? assetPath, required String slotType, double size = 26.0}) {
    IconData fallbackIcon = Icons.shield;
    Color iconColor = Colors.purpleAccent;

    if (slotType.contains('neck')) { fallbackIcon = Icons.diamond; iconColor = Colors.cyanAccent; } 
    else if (slotType.contains('arms')) { fallbackIcon = Icons.back_hand; iconColor = Colors.greenAccent; } 
    else if (slotType.contains('belt')) { fallbackIcon = Icons.accessibility; iconColor = Colors.orangeAccent; } 
    else if (slotType.contains('mask')) { fallbackIcon = Icons.masks; iconColor = Colors.redAccent; } 
    else if (slotType.contains('character')) { fallbackIcon = Icons.person; iconColor = Colors.purpleAccent; }

    if (assetPath == null || assetPath.trim().isEmpty) {
      return Icon(fallbackIcon, size: size, color: iconColor);
    }
    
    if (assetPath.startsWith('http')) {
      return Image.network(
        assetPath, width: size, height: size, fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) => Icon(fallbackIcon, size: size, color: iconColor),
      );
    }

    return Image.asset(
      assetPath, width: size, height: size, fit: BoxFit.contain,
      errorBuilder: (context, error, stackTrace) => Icon(fallbackIcon, size: size, color: iconColor),
    );
  }

  Widget _buildStatRow(String label, double baseValue, double draftValue, bool isLowerBetter) {
    bool isBuffed = isLowerBetter ? (draftValue < baseValue) : (draftValue > baseValue);
    bool isNerfed = isLowerBetter ? (draftValue > baseValue) : (draftValue < baseValue);
    Color valColor = isBuffed ? Colors.greenAccent : (isNerfed ? Colors.redAccent : Colors.grey);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70)),
          Text(draftValue.toStringAsFixed(1), style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: valColor)),
        ],
      ),
    );
  }

  Widget _buildMaskSlot(int index, String mId, bool isSelected) {
    Color slotColor;
    switch (index) {
      case 0: slotColor = Colors.cyanAccent; break; 
      case 1: slotColor = Colors.purpleAccent; break; 
      case 2: slotColor = Colors.orangeAccent; break; 
      case 3: slotColor = Colors.redAccent; break; 
      default: slotColor = Colors.white; break;
    }

    String maskName = 'EMPTY';
    String? assetPath;
    
    if (mId.isNotEmpty) {
      final maskData = _masksCatalog[mId];
      if (maskData != null) {
        maskName = maskData['name'] ?? mId.replaceAll('_', ' ').toUpperCase();
        assetPath = maskData['asset_path'] ?? maskData['thumbnail_path'];
      } else if (mId == 'standard') {
        maskName = 'GRAVE STINGER'; 
      } else {
        maskName = mId.replaceAll('_', ' ').toUpperCase();
      }
    }

    Widget slotCard = GestureDetector(
      onTap: () => mId.isEmpty && isSelected ? _assignSelectedToSlot('mask_${index + 1}') : _clearSlot('mask_${index + 1}'),
      child: SizedBox(
        width: 70, 
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomPaint(
                  size: const Size(16, 16),
                  painter: MiniWheelPainter(index, slotColor),
                ),
                if (mId.isNotEmpty) ...[
                  const SizedBox(width: 6),
                  CustomPaint(
                    size: const Size(16, 16),
                    painter: AttackTypeIconPainter(mId, slotColor),
                  ),
                ]
              ],
            ),
            const SizedBox(height: 6),
            
            Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                border: Border.all(
                  color: isSelected && mId.isEmpty ? Colors.greenAccent : slotColor.withOpacity(0.6), 
                  width: 1.5
                ),
                color: mId.isNotEmpty ? slotColor.withOpacity(0.15) : Colors.black45,
                borderRadius: BorderRadius.circular(8),
              ),
              child: mId.isNotEmpty 
                ? Center(child: buildSafeItemThumbnail(assetPath: assetPath, slotType: 'mask', size: 36.0))
                : const Icon(Icons.add, size: 24, color: Colors.white24),
            ),
            const SizedBox(height: 6),
            
            Text(
              maskName,
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 8,
                fontWeight: mId.isNotEmpty ? FontWeight.bold : FontWeight.normal,
                color: mId.isNotEmpty ? Colors.white : Colors.white38,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
      ),
    );

    if (index == 0) {
      return Showcase(
        key: _maskSlotKey,
        description: 'STEP 6: Tap this empty slot to bind your mask.',
        disposeOnTap: true,
        onTargetClick: () {
          if (mId.isEmpty && isSelected) {
            _assignSelectedToSlot('mask_${index + 1}');
          } else {
            _clearSlot('mask_${index + 1}');
          }
          Future.delayed(const Duration(milliseconds: 300), () {
            if (mounted && _scaffoldKey.currentContext != null) {
              ShowCaseWidget.of(_scaffoldKey.currentContext!).startShowCase([_sealKey]);
            }
          });
        },
        child: slotCard,
      );
    }
    
    return slotCard;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(backgroundColor: Color(0xFF111111), body: Center(child: CircularProgressIndicator(color: Colors.purpleAccent)));
    }

    final activeCharData = _charactersCatalog[_previewCharacterId] ?? {};
    double baseSpeed = (activeCharData['base_speed'] as num?)?.toDouble() ?? 200.0;
    double baseEnergy = (activeCharData['max_energy'] as num?)?.toDouble() ?? 10.0;
    double baseRegen = (activeCharData['energy_regen'] as num?)?.toDouble() ?? 0.5;
    double baseSwapSpeed = (activeCharData['swap_speed_modifier'] as num?)?.toDouble() ?? 1.0;
    double baseFootprint = 1.0;

    return ShowCaseWidget(
      builder: (context) => Scaffold(
        key: _scaffoldKey,
        backgroundColor: const Color(0xFF111111),
        appBar: AppBar(
          title: const Text('THE CRYPT', style: TextStyle(letterSpacing: 2.0, color: Colors.purpleAccent, fontSize: 16, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
          backgroundColor: Colors.black,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.of(context).pop(),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16.0),
              child: Row(
                children: [
                  const Icon(Icons.dark_mode, color: Colors.redAccent, size: 14),
                  const SizedBox(width: 4),
                  Text('$_playerShadows', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
                  
                  const SizedBox(width: 12),
                  
                  const Icon(Icons.monetization_on, color: Colors.amber, size: 14),
                  const SizedBox(width: 4),
                  Text('$_playerCoins', style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
        body: Column(
          children: [
          // --- PENDING REWARDS BANNER ---
          if (_pendingRewards.isNotEmpty)
            Container(
              height: 50,
              decoration: BoxDecoration(
                color: Colors.red[900]?.withOpacity(0.8),
                border: const Border(bottom: BorderSide(color: Colors.redAccent, width: 2)),
              ),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: _pendingRewards.length,
                itemBuilder: (context, index) {
                  final reward = _pendingRewards[index];
                  return GestureDetector(
                    onTap: () => _claimReward(reward['id']),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        border: Border.all(color: Colors.white70),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Center(
                        child: Text(
                          'CLAIM: ${reward['item_id'].toString().toUpperCase()}',
                          style: const TextStyle(
                            fontFamily: 'Orbitron', 
                            color: Colors.white, 
                            fontWeight: FontWeight.bold, 
                            fontSize: 12,
                            letterSpacing: 1.2
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),

          Container(
            height: 175,
            color: Colors.black54,
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
            child: Row(
              children: [
                Expanded(
                  flex: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: Alignment.centerLeft,
                        child: Text(
                          (activeCharData['name'] as String?)?.toUpperCase() ?? 'OPERATIVE', 
                          maxLines: 1,
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 1.0, fontFamily: 'Orbitron'),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: [
                          Text(
                            (activeCharData['species'] as String?)?.toUpperCase() ?? 'UNKNOWN SPECIES',
                            style: const TextStyle(fontSize: 11, color: Colors.purpleAccent, letterSpacing: 1.5, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                          ),
                          const SizedBox(width: 6),
                          GestureDetector(
                            onTap: () {
                              showDialog(context: context, builder: (_) => const CircleOfTormentOverlay());
                            },
                            child: const Icon(Icons.help_outline, color: Colors.white54, size: 14),
                          ),
                        ],
                      ),
                      const Divider(color: Colors.purpleAccent, height: 6, thickness: 1),
                      _buildStatRow('Speed', baseSpeed, _getDraftStat('speed', baseSpeed), false),
                      _buildStatRow('Max Energy', baseEnergy, _getDraftStat('energy_max', baseEnergy), false),
                      _buildStatRow('Regen', baseRegen, _getDraftStat('regen', baseRegen), false),
                      _buildStatRow('Swap Time', baseSwapSpeed, _getDraftStat('swap_speed_modifier', baseSwapSpeed), true),
                      _buildStatRow('Footstep Noise', baseFootprint, _getDraftStat('footprint_reduction', baseFootprint), true),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  flex: 1,
                  child: GestureDetector(
                    onPanUpdate: (details) {
                      _mannequinGame.isAutoRotating = false;
                      if (_mannequinGame.mannequin != null) {
                        _mannequinGame.mannequin!.targetAngle += details.delta.dx * 0.02;
                      }
                    },
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        color: Colors.black38,
                        child: GameWidget(game: _mannequinGame),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Container(
              color: Colors.black87,
              child: Column(
                children: [
                  TabBar(
                    controller: _tabController,
                    isScrollable: true, 
                    indicatorColor: Colors.purpleAccent,
                    labelColor: Colors.purpleAccent,
                    unselectedLabelColor: Colors.white54,
                    labelPadding: const EdgeInsets.symmetric(horizontal: 10),
                    labelStyle: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 12),
                    tabs: [
                      const Tab(icon: Icon(Icons.person, size: 18), text: 'Char'),
                      Showcase(
                        key: _masksTabKey,
                        description: 'STEP 4: Tap here to view your Masks.',
                        disposeOnTap: true,
                        onTargetClick: () {
                          _tabController.animateTo(1);
                          Future.delayed(const Duration(milliseconds: 400), () {
                            if (mounted && _scaffoldKey.currentContext != null) {
                              ShowCaseWidget.of(_scaffoldKey.currentContext!).startShowCase([_inventoryMaskKey]);
                            }
                          });
                        },
                        child: const Tab(icon: Icon(Icons.masks, size: 18), text: 'Masks'),
                      ),
                      const Tab(icon: Icon(Icons.diamond, size: 18), text: 'Neck'),
                      const Tab(icon: Icon(Icons.back_hand, size: 18), text: 'Arms'),
                      const Tab(icon: Icon(Icons.accessibility, size: 18), text: 'Belt'),
                      const Tab(icon: Icon(Icons.analytics_outlined, size: 18), text: 'Intel'), 
                    ],
                  ),
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        _buildInventoryGrid('character'),
                        _buildInventoryGrid('mask'),
                        _buildInventoryGrid('wearable_neck'),
                        _buildInventoryGrid('wearable_arms'),
                        _buildInventoryGrid('wearable_belt'),
                        const SingleChildScrollView(
                          child: TacticalDossierPanel(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
            decoration: const BoxDecoration(
              color: Color(0xFF0D0D12),
              border: Border(top: BorderSide(color: Colors.purpleAccent, width: 1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('ATTUNED WARDS & MASKS', 
                      style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.orangeAccent, letterSpacing: 1.0, fontFamily: 'Orbitron')),
                    Text(
                      _selectedInventoryId != null ? 'TAP SLOT TO BIND' : 'TAP TO DISMISS',
                      style: const TextStyle(fontSize: 9, color: Colors.white38, fontFamily: 'Orbitron'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(4, (i) {
                    String mId = _draftMasks[i];
                    bool isSelected = _selectedItemType == 'mask';
                    return _buildMaskSlot(i, mId, isSelected);
                  }),
                ),
                const SizedBox(height: 12),

                Row(
                  children: [
                    Expanded(child: _buildWearableSlot('wearable_neck', 'Neck', Icons.diamond, Colors.cyanAccent)),
                    const SizedBox(width: 6),
                    Expanded(child: _buildWearableSlot('wearable_arms', 'Arms', Icons.back_hand, Colors.greenAccent)),
                    const SizedBox(width: 6),
                    Expanded(child: _buildWearableSlot('wearable_belt', 'Belt', Icons.accessibility, Colors.orangeAccent)),
                  ],
                ),
              ],
            ),
          ),

          if (_hasUnsavedChanges)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
              color: Colors.black,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton(
                    onPressed: _revertDraft,
                    child: const Text('DISMISS', style: TextStyle(color: Colors.redAccent, letterSpacing: 1.5, fontSize: 13, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                  ),
                  Showcase(
                    key: _sealKey,
                    description: 'STEP 7: Seal your attunement to save changes.',disposeOnTap: true,
                    onTargetClick: () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.setString('tutorial_phase', 'match');
                      _commitDraft();
                    },
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green[700],
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      ),
                      onPressed: () async {
                        final prefs = await SharedPreferences.getInstance();
                        if (prefs.getString('tutorial_phase') == 'loadout') {
                          await prefs.setString('tutorial_phase', 'match');
                        }
                        _commitDraft();
                      },
                      child: const Text('SEAL ATTUNEMENT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.2, fontSize: 13, fontFamily: 'Orbitron')),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    ),
    );
  }

  Widget _buildWearableSlot(String slotKey, String label, IconData icon, Color color) {
    String? assignedId = _draftLoadout[slotKey];
    bool isSelected = _selectedItemType == slotKey;
    
    return GestureDetector(
      onTap: () => assignedId == null && isSelected ? _assignSelectedToSlot(slotKey) : _clearSlot(slotKey),
      child: Container(
        height: 38,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          border: Border.all(color: isSelected && assignedId == null ? Colors.greenAccent : Colors.white24),
          color: assignedId != null ? color.withOpacity(0.15) : Colors.black45,
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          children: [
            Icon(icon, color: assignedId != null ? color : Colors.white30, size: 16),
            const SizedBox(width: 4),
            Expanded(
              child: Text(
                assignedId != null ? _wearablesCatalog[assignedId]?.name ?? 'UNKNOWN' : label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: assignedId != null ? Colors.white : Colors.white54,
                  fontSize: 10,
                  fontFamily: 'Orbitron',
                  fontWeight: assignedId != null ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
            Icon(
              assignedId == null ? Icons.add : Icons.close, 
              color: assignedId == null ? Colors.white24 : Colors.redAccent, 
              size: 14,
            ),
          ],
        ),
      ),
    );
  }

  // --- REDUCED HORIZONTAL BOUNDS FOR MAXIMUM THUMBNAIL VISIBILITY ---
  Widget _buildInventoryGrid(String targetItemType) {
    if (targetItemType == 'character') {
      return _buildCharacterCryptGrid();
    }

    List<Map<String, dynamic>> allCatalogItems = [];
    if (targetItemType == 'mask') {
      allCatalogItems = _masksCatalog.values.toList();
    } else {
      allCatalogItems = _wearablesCatalog.values
          .where((w) => w.slotType == targetItemType)
          .map((w) => {
                'id': w.id,
                'name': w.name,
                'slot_type': w.slotType,
                'price': w.price,
                'currency': w.currency,
                'asset_path': w.assetPath,
              })
          .toList();
    }

    // --- NEW: SMART SORTING HIERARCHY ---
    allCatalogItems.sort((a, b) {
      final idA = a['id'].toString();
      final idB = b['id'].toString();

      // 1. Tutorial Failsafe: The Standard Mask is ALWAYS position #1
      if (targetItemType == 'mask') {
        if (idA == 'standard' && idB != 'standard') return -1;
        if (idB == 'standard' && idA != 'standard') return 1;
      }

      // 2. Owned items jump to the front
      bool isOwnedA = _inventory.any((i) => i['item_id'] == idA && (i['item_type'] == targetItemType || targetItemType.startsWith('wearable')));
      bool isOwnedB = _inventory.any((i) => i['item_id'] == idB && (i['item_type'] == targetItemType || targetItemType.startsWith('wearable')));
      
      if (isOwnedA && !isOwnedB) return -1;
      if (!isOwnedA && isOwnedB) return 1;

      // 3. Sort the rest by lowest price first
      int priceA = a['price'] ?? 0;
      int priceB = b['price'] ?? 0;
      return priceA.compareTo(priceB);
    });
    // ------------------------------------

    if (allCatalogItems.isEmpty) {
      return const Center(child: Text('No relics cataloged.', style: TextStyle(color: Colors.white54, fontFamily: 'Orbitron')));
    }
    
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxHeight: 95), 
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 0.0),
          scrollDirection: Axis.horizontal, 
          itemCount: allCatalogItems.length,
          separatorBuilder: (context, index) => const SizedBox(width: 8),
          itemBuilder: (context, index) {
            final item = allCatalogItems[index];
            final itemId = item['id'].toString();
            final name = item['name'] ?? itemId.replaceAll('_', ' ').toUpperCase();
            final price = item['price'] ?? 0;
            final currency = item['currency'] ?? 'shadows';
            final assetPath = item['asset_path'] ?? item['thumbnail_path'];

            bool isOwned = _inventory.any((i) => i['item_id'] == itemId && (i['item_type'] == targetItemType || targetItemType.startsWith('wearable')));
            bool isSelected = _selectedInventoryId == itemId;

            Color borderColor = Colors.white12;
            if (isSelected) borderColor = Colors.purpleAccent;
            else if (!isOwned) borderColor = (currency == 'coins' ? Colors.amber.withOpacity(0.4) : Colors.redAccent.withOpacity(0.4));

            Widget card = SizedBox(
              width: 76, 
              child: GestureDetector(
                onTap: () {
                  if (isOwned) {
                    _selectInventoryItem(targetItemType, itemId);
                  } else {
                    _showPurchaseConfirm(
                      itemType: targetItemType,
                      itemId: itemId,
                      name: name,
                      price: price,
                      currency: currency,
                    );
                  }
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: isSelected 
                        ? Colors.purpleAccent.withOpacity(0.2) 
                        : (isOwned ? Colors.grey[900] : Colors.black54),
                    border: Border.all(color: borderColor, width: isSelected ? 2 : 1.2),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          buildSafeItemThumbnail(assetPath: assetPath, slotType: targetItemType, size: 42.0),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(
                                child: Text(
                                  name, 
                                  textAlign: TextAlign.center, 
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 9, 
                                    color: isSelected ? Colors.white : (isOwned ? Colors.white70 : Colors.white38),
                                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                    fontFamily: 'Orbitron',
                                  ),
                                ),
                              ),
                              if (targetItemType == 'mask') ...[
                                const SizedBox(width: 2),
                                GestureDetector(
                                  onTap: () {
                                    final desc = item['description']?.toString() ?? 'A terrifying mask with standard haunting capabilities.';
                                    final eCost = (item['energy_cost'] as num?)?.toDouble() ?? 2.0;
                                    final mCd = (item['cooldown'] as num?)?.toDouble() ?? 2.0;
                                    final mRange = (item['range'] as num?)?.toDouble() ?? 250.0;
                                    
                                    showDialog(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                        backgroundColor: Colors.black.withOpacity(0.95),
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                          side: const BorderSide(color: Colors.cyanAccent, width: 1.5),
                                        ),
                                        title: Text(
                                          name.toUpperCase(),
                                          style: const TextStyle(
                                            color: Colors.white, 
                                            fontFamily: 'Orbitron', 
                                            fontWeight: FontWeight.bold,
                                            shadows: [Shadow(color: Colors.cyanAccent, blurRadius: 4)]
                                          ),
                                        ),
                                        content: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              desc,
                                              style: const TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Orbitron', height: 1.4),
                                            ),
                                            const SizedBox(height: 16),
                                            const Divider(color: Colors.white30),
                                            const SizedBox(height: 16),
                                            Text('ENERGY COST: $eCost', style: const TextStyle(color: Colors.greenAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                                            const SizedBox(height: 4),
                                            Text('COOLDOWN: ${mCd}s', style: const TextStyle(color: Colors.redAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                                            const SizedBox(height: 4),
                                            Text('RANGE: $mRange', style: const TextStyle(color: Colors.yellowAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                                          ],
                                        ),
                                        actions: [
                                          TextButton(
                                            onPressed: () => Navigator.of(ctx).pop(),
                                            child: const Text('CLOSE', style: TextStyle(color: Colors.cyanAccent, fontFamily: 'Orbitron', fontWeight: FontWeight.bold)),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                  child: const Icon(Icons.info_outline, color: Colors.cyanAccent, size: 12),
                                ),
                              ],
                            ],
                          ),
                          const SizedBox(height: 4),
                          if (!isOwned)
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(currency == 'coins' ? Icons.monetization_on : Icons.dark_mode, size: 9, color: currency == 'coins' ? Colors.amber : Colors.redAccent),
                                const SizedBox(width: 2),
                                Text('$price', style: TextStyle(color: currency == 'coins' ? Colors.amber : Colors.redAccent, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                              ],
                            )
                          else
                            const Text('OWNED', style: TextStyle(color: Colors.greenAccent, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );

            if (targetItemType == 'mask' && itemId == 'standard' && isOwned) {
              return Showcase(
                key: _inventoryMaskKey,
                description: 'STEP 5: Tap the Standard Mask to select it.',
                disposeOnTap: true,
                onTargetClick: () {
                  _selectInventoryItem(targetItemType, itemId);
                  Future.delayed(const Duration(milliseconds: 300), () {
                    if (mounted && _scaffoldKey.currentContext != null) {
                      ShowCaseWidget.of(_scaffoldKey.currentContext!).startShowCase([_maskSlotKey]);
                    }
                  });
                },
                child: card,
              );
            }
            return card;
          },
        ),
      ),
    );
  }

  // --- REDUCED VERTICAL BOUNDS FOR MAXIMUM THUMBNAIL VISIBILITY ---
  Widget _buildCharacterCryptGrid() {
    Map<String, List<Map<String, dynamic>>> groupedChars = {};

    _charactersCatalog.forEach((charId, charData) {
      String species = (charData['species'] ?? 'UNKNOWN').toString().toUpperCase();
      
      bool isOwned = _ownedCharacters.contains(charId);
      int currentShards = _userShards[charId] ?? 0;
      int maxShards = charData['unlock_threshold'] ?? 10; 
      
      String state = 'progression';
      if (isOwned) {
        state = 'owned';
      } else if (currentShards >= maxShards) {
        state = 'bind';
      }

      groupedChars.putIfAbsent(species, () => []).add({
        'id': charId,
        'state': state, 
        'is_owned': isOwned, // Added for sorting
        'shards_needed': max(0, maxShards - currentShards), // Added for sorting
        'name': charData['name'] ?? charId,
        'thumbnail_path': charData['thumbnail_path'],
        'price': charData['price'] ?? 0,
        'currency': charData['currency'] ?? 'shadows',
        'current_shards': currentShards,
        'max_shards': maxShards,
        'bind_cost': maxShards * 25,
      });
    });

    // --- NEW: SORT THE CHARACTERS WITHIN EACH SPECIES ---
    groupedChars.forEach((species, chars) {
      chars.sort((a, b) {
        // 1. Owned characters always jump to the front
        if (a['is_owned'] && !b['is_owned']) return -1;
        if (!a['is_owned'] && b['is_owned']) return 1;
        
        // 2. If neither are owned, sort by lowest shards needed
        if (!a['is_owned'] && !b['is_owned']) {
          return (a['shards_needed'] as int).compareTo(b['shards_needed'] as int);
        }
        
        // 3. Otherwise, keep their natural catalog order
        return 0;
      });
    });

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: groupedChars.keys.length,
      itemBuilder: (context, sectionIndex) {
        String speciesName = groupedChars.keys.elementAt(sectionIndex);
        List<Map<String, dynamic>> charsInSpecies = groupedChars[speciesName]!;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 8, bottom: 12, left: 4),
              child: Text(
                '$speciesName OPERATIVES', 
                style: const TextStyle(color: Colors.purpleAccent, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 2.0, fontFamily: 'Orbitron')
              ),
            ),
            
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, 
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
                childAspectRatio: 0.90, 
              ),
              itemCount: charsInSpecies.length,
              itemBuilder: (context, index) {
                final char = charsInSpecies[index];
                final charId = char['id'];
                final state = char['state'];
                
                bool isEquipped = _draftCharacterId == charId;
                bool isPreviewed = _previewCharacterId == charId && !isEquipped;
                
                Color borderColor = Colors.white12;
                if (isEquipped) borderColor = Colors.greenAccent;
                else if (isPreviewed) borderColor = Colors.white; 
                else if (state == 'bind') borderColor = Colors.amberAccent;
                else if (state == 'progression') borderColor = Colors.purpleAccent.withOpacity(0.5);

                return GestureDetector(
                  onTap: () {
                    if (state == 'owned') {
                      _selectInventoryItem('character', charId);
                    } else {
                      // First tap: preview the character on the 3D mannequin
                      if (_previewCharacterId != charId) {
                        setState(() {
                          _previewCharacterId = charId;
                        });
                        _mannequinGame.loadBaseCharacter(charId);
                      } 
                      // Second tap on the previewed character:
                      else if (state == 'bind') {
                        _bindOperative(charId, char['bind_cost'], char['name'] ?? charId);
                      } else {
                        // Allow direct purchase with Shadows or Coins!
                        _showPurchaseConfirm(
                          itemType: 'character',
                          itemId: charId,
                          name: char['name'] ?? charId,
                          price: char['price'] ?? 0,
                          currency: char['currency'] ?? 'shadows',
                        );
                      }
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: isEquipped ? Colors.greenAccent.withOpacity(0.1) : Colors.black45,
                      border: Border.all(color: borderColor, width: isEquipped || state == 'bind' || isPreviewed ? 2 : 1),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: Center(
                            child: charId == 'default'
                                ? IgnorePointer( // Prevents the mini 3D canvas from intercepting scroll gestures
                                    child: SizedBox(
                                      width: 90,
                                      height: 90,
                                      child: GameWidget(
                                        game: MannequinGame()..loadBaseCharacter('default'),
                                      ),
                                    ),
                                  )
                                : buildSafeItemThumbnail(assetPath: char['thumbnail_path'], slotType: 'character', size: 90.0),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
                          decoration: const BoxDecoration(
                            color: Colors.black87,
                            borderRadius: BorderRadius.vertical(bottom: Radius.circular(5)),
                          ),
                          child: Column(
                            children: [
                              Text(
                                char['name'].toString().toUpperCase(),
                                textAlign: TextAlign.center,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                              ),
                              const SizedBox(height: 4),
                              
                              if (isEquipped)
                                const Text('EQUIPPED', textAlign: TextAlign.center, style: TextStyle(color: Colors.greenAccent, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'))
                              
                              else if (state == 'owned')
                                const Text('TAP TO BIND', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 8, fontFamily: 'Orbitron'))
                              
                              else if (state == 'bind')
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(isPreviewed ? 'CONFIRM ' : 'EVOLVE ', style: const TextStyle(color: Colors.amberAccent, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                                    const Icon(Icons.monetization_on, size: 10, color: Colors.amberAccent),
                                    const SizedBox(width: 2),
                                    Text('${char['bind_cost']}', style: const TextStyle(color: Colors.amberAccent, fontSize: 9, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                                  ],
                                )
                              
                              else if (state == 'progression')
                                Column(
                                  children: [
                                    // If previewing, prompt them to buy with currency
                                    if (isPreviewed)
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          const Text('BUY ', style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                                          Icon(
                                            char['currency'] == 'coins' ? Icons.monetization_on : Icons.dark_mode, 
                                            size: 9, 
                                            color: char['currency'] == 'coins' ? Colors.amber : Colors.redAccent
                                          ),
                                          const SizedBox(width: 2),
                                          Text(
                                            '${char['price']}', 
                                            style: TextStyle(
                                              color: char['currency'] == 'coins' ? Colors.amber : Colors.redAccent, 
                                              fontSize: 8, 
                                              fontWeight: FontWeight.bold,
                                              fontFamily: 'Orbitron'
                                            )
                                          ),
                                        ],
                                      )
                                    else
                                      Text('${char['current_shards']} / ${char['max_shards']}', style: const TextStyle(color: Colors.grey, fontSize: 8, fontFamily: 'Orbitron')),
                                    const SizedBox(height: 2),
                                    LinearProgressIndicator(
                                      value: (char['current_shards'] / char['max_shards']).clamp(0.0, 1.0),
                                      backgroundColor: Colors.black,
                                      color: Colors.purpleAccent,
                                      minHeight: 2,
                                    ),
                                  ],
                                )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
          ],
        );
      },
    );
  }
}

class MannequinGame extends FlameGame {
  VoxelCharacterComponent? mannequin;
  double _rotationTimer = 0.0;
  bool isAutoRotating = true; 

  @override
  Color backgroundColor() => Colors.transparent; 

  Future<void> loadBaseCharacter(String characterId) async {
    Map<String, ui.Image> images = {};
    Map<String, dynamic>? rig;

    try {
      String zipPath = 'assets/character_assets.zip'; 
      if (characterId != 'default') {
        final charRes = await Supabase.instance.client
            .from('characters').select('zip_asset_path').eq('id', characterId).eq('enabled', true).maybeSingle();
        if (charRes != null && charRes['zip_asset_path'] != null) {
          zipPath = charRes['zip_asset_path'];
        }
      }

      List<int> bytes = await CharacterAssetManager.getZipBytes(zipPath);

      final archive = ZipDecoder().decodeBytes(bytes);

      for (final file in archive) {
        if (file.isFile) {
          if (file.name == 'rig.json') {
            rig = jsonDecode(utf8.decode(file.content as List<int>));
          } else if (file.name.endsWith('.png')) {
            final codec = await ui.instantiateImageCodec(file.content as Uint8List);
            final frameInfo = await codec.getNextFrame();
            images[file.name] = frameInfo.image;
          }
        }
      }

      if (rig != null) {
        final newMannequin = VoxelCharacterComponent(images: images, rigData: rig, hitboxSize: Vector2(54, 54));
        if (hasLayout) newMannequin.position = size / 2;
        
        removeWhere((component) => component is VoxelCharacterComponent);
        mannequin = newMannequin;
        add(mannequin!);
      }
    } catch (e) {
      debugPrint('Character ZIP load error: $e');
    }
  }

  Future<void> setPreviewMask(String? maskId) async {
    if (mannequin == null) return;
    
    isAutoRotating = false;
    mannequin!.targetAngle = 0.0; 

    if (maskId == null || maskId.isEmpty) {
      mannequin!.activeMaskImage = null;
      return;
    }
    try {
      mannequin!.activeMaskImage = await images.load('${maskId}_mask.png');
    } catch (e) {
      debugPrint('Mask asset missing: $e');
    }
  }

  void triggerEquipAnimation() {
    if (mannequin != null) {
      mannequin!.isHighlighted = true;
      Future.delayed(const Duration(milliseconds: 250), () {
        if (mannequin != null) mannequin!.isHighlighted = false;
      });
    }
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (mannequin != null && isAutoRotating) {
      _rotationTimer += dt * 0.4;
      mannequin!.targetAngle = _rotationTimer;
      mannequin!.isMoving = true; 
    }
  }

  @override
  void onGameResize(Vector2 gameSize) {
    super.onGameResize(gameSize);
    if (mannequin != null) mannequin!.position = gameSize / 2;
  }
}

class CircleOfTormentOverlay extends StatelessWidget {
  const CircleOfTormentOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.grey[900],
      // 1. WIDEN THE DIALOG: Reduce the default 40px margins down to 16px
      insetPadding: const EdgeInsets.symmetric(horizontal: 16.0),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: Colors.purpleAccent, width: 2),
      ),
      title: const Text(
        'THE CIRCLE OF TORMENT',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontFamily: 'Orbitron'),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Strike your favored prey to inflict +15% Stun Duration and Area of Effect.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70, fontSize: 13, fontStyle: FontStyle.italic),
          ),
          const SizedBox(height: 20),
          _buildRow(Icons.visibility_off, 'GHOSTS', 'terrify', Icons.person, 'HUMANOIDS', Colors.blueGrey, Colors.blue),
          _buildRow(Icons.person, 'HUMANOIDS', 'dismantle', Icons.memory, 'CYBERNETICS', Colors.blue, Colors.cyan),
          _buildRow(Icons.memory, 'CYBERNETICS', 'analyze', Icons.coronavirus, 'ALIENS', Colors.cyan, Colors.greenAccent),
          _buildRow(Icons.coronavirus, 'ALIENS', 'mutate', Icons.pets, 'BEASTS', Colors.greenAccent, Colors.orange),
          _buildRow(Icons.pets, 'BEASTS', 'devour', Icons.visibility_off, 'GHOSTS', Colors.orange, Colors.blueGrey),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('UNDERSTOOD', style: TextStyle(color: Colors.white54, fontFamily: 'Orbitron')),
        ),
      ],
    );
  }

  Widget _buildRow(IconData icon1, String text1, String action, IconData icon2, String text2, Color c1, Color c2) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      // 2. THE FAILSAFE: Automatically scales the text down if it's too wide for the phone
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon1, color: c1, size: 20),
            const SizedBox(width: 6),
            Text(text1, style: TextStyle(color: c1, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Orbitron')),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text(action, style: const TextStyle(color: Colors.white54, fontSize: 10, fontStyle: FontStyle.italic)),
            ),
            Icon(icon2, color: c2, size: 20),
            const SizedBox(width: 6),
            Text(text2, style: TextStyle(color: c2, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Orbitron')),
          ],
        ),
      ),
    );
  }
}

class MiniWheelPainter extends CustomPainter {
  final int activeSlot;
  final Color slotColor;

  MiniWheelPainter(this.activeSlot, this.slotColor);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    final bgPaint = Paint()..color = Colors.white12..style = PaintingStyle.fill;
    canvas.drawCircle(center, radius, bgPaint);

    final activePaint = Paint()..color = slotColor..style = PaintingStyle.fill;

    final List<List<double>> quadrantAngles = [
      [pi, pi / 2],      // 0: Top-Left
      [-pi / 2, pi / 2], // 1: Top-Right
      [pi / 2, pi / 2],  // 2: Bottom-Left
      [0, pi / 2],       // 3: Bottom-Right
    ];

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      quadrantAngles[activeSlot][0],
      quadrantAngles[activeSlot][1],
      true,
      activePaint,
    );

    final linePaint = Paint()..color = Colors.black..strokeWidth = 1.0;
    canvas.drawLine(Offset(radius, 0), Offset(radius, radius * 2), linePaint);
    canvas.drawLine(Offset(0, radius), Offset(radius * 2, radius), linePaint);
    
    canvas.drawCircle(center, radius, Paint()..color = Colors.white30..style = PaintingStyle.stroke);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class AttackTypeIconPainter extends CustomPainter {
  final String maskId;
  final Color color;
  
  AttackTypeIconPainter(this.maskId, this.color);
  
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final fillPaint = Paint()..color = color..style = PaintingStyle.fill;
    final strokePaint = Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 1.5;

    if (maskId == 'standard') {
      final path = Path()
        ..moveTo(c.dx, c.dy + 4)
        ..lineTo(c.dx - 6, c.dy - 6)
        ..arcToPoint(Offset(c.dx + 6, c.dy - 6), radius: const Radius.circular(8), clockwise: true)
        ..close();
      canvas.drawPath(path, fillPaint);
    } 
    else if (maskId == 'siren') {
      canvas.drawArc(Rect.fromCircle(center: Offset(c.dx - 2, c.dy), radius: 3), pi / 2, pi, false, strokePaint);
      canvas.drawArc(Rect.fromCircle(center: Offset(c.dx - 2, c.dy), radius: 5), -pi/3, (2*pi)/3, false, strokePaint);
      canvas.drawArc(Rect.fromCircle(center: Offset(c.dx - 2, c.dy), radius: 8), -pi/3, (2*pi)/3, false, strokePaint);
    } 
    else if (maskId == 'vermin') {
      canvas.drawCircle(Offset(c.dx - 5, c.dy), 1.5, fillPaint);
      canvas.drawCircle(Offset(c.dx, c.dy), 1.5, fillPaint);
      canvas.drawCircle(Offset(c.dx + 5, c.dy), 1.5, fillPaint);
    } 
    else if (maskId == 'flying') {
      final path = Path()
        ..moveTo(c.dx - 7, c.dy - 2)
        ..quadraticBezierTo(c.dx - 3, c.dy - 5, c.dx, c.dy - 1)
        ..quadraticBezierTo(c.dx + 3, c.dy - 5, c.dx + 7, c.dy - 2);
      canvas.drawPath(path, strokePaint);
      canvas.drawLine(Offset(c.dx - 3, c.dy + 2), Offset(c.dx - 3, c.dy + 5), strokePaint);
      canvas.drawLine(Offset(c.dx + 3, c.dy + 2), Offset(c.dx + 3, c.dy + 5), strokePaint);
    }
    // --- NEW TACTICAL MASKS ---
    else if (maskId == 'gorgon') {
      // Reptilian Eye with vertical slit pupil
      final path = Path()
        ..moveTo(c.dx - 7, c.dy)
        ..quadraticBezierTo(c.dx, c.dy - 6, c.dx + 7, c.dy)
        ..quadraticBezierTo(c.dx, c.dy + 6, c.dx - 7, c.dy);
      canvas.drawPath(path, strokePaint);
      canvas.drawLine(Offset(c.dx, c.dy - 3), Offset(c.dx, c.dy + 3), strokePaint..strokeWidth = 2);
    }
    else if (maskId == 'poltergeist') {
      // Shattered Diamond Ward with glowing core
      final path = Path()
        ..moveTo(c.dx, c.dy - 6)
        ..lineTo(c.dx + 6, c.dy)
        ..lineTo(c.dx, c.dy + 6)
        ..lineTo(c.dx - 6, c.dy)
        ..close();
      canvas.drawPath(path, strokePaint);
      canvas.drawCircle(c, 1.5, fillPaint);
    }
    else if (maskId == 'banshee') {
      // Screaming Mouth with directional sonic waves
      canvas.drawOval(Rect.fromCenter(center: Offset(c.dx - 4, c.dy), width: 3, height: 8), fillPaint);
      canvas.drawArc(Rect.fromCircle(center: Offset(c.dx - 2, c.dy), radius: 5), -pi/3, (2*pi)/3, false, strokePaint);
      canvas.drawArc(Rect.fromCircle(center: Offset(c.dx - 2, c.dy), radius: 8), -pi/3, (2*pi)/3, false, strokePaint);
    }
    else if (maskId == 'wendigo') {
      // Jagged Antlers
      final path = Path()
        ..moveTo(c.dx, c.dy + 5)
        ..lineTo(c.dx - 5, c.dy - 4)
        ..moveTo(c.dx, c.dy + 5)
        ..lineTo(c.dx + 5, c.dy - 4)
        ..moveTo(c.dx - 2.5, c.dy + 0.5)
        ..lineTo(c.dx - 6, c.dy + 1)
        ..moveTo(c.dx + 2.5, c.dy + 0.5)
        ..lineTo(c.dx + 6, c.dy + 1);
      canvas.drawPath(path, strokePaint);
    }
    else if (maskId == 'parasite') {
      // Circular Maw with inward-facing teeth
      canvas.drawCircle(c, 6, strokePaint);
      for (int i = 0; i < 8; i++) {
        double angle = i * (pi / 4);
        canvas.drawLine(
          Offset(c.dx + cos(angle) * 6, c.dy + sin(angle) * 6),
          Offset(c.dx + cos(angle) * 3, c.dy + sin(angle) * 3),
          strokePaint..strokeWidth = 1.0
        );
      }
    } 
    else {
      canvas.drawCircle(c, 2, fillPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class TacticalDossierPanel extends StatelessWidget {
  const TacticalDossierPanel({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, String>?>(
      future: TacticalAnalyzer.generateDossier(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: CircularProgressIndicator(color: Colors.cyanAccent),
            ),
          );
        }

        final data = snapshot.data;
        if (data == null) return const SizedBox.shrink();

        return Container(
          margin: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 8.0),
          padding: const EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.6),
            border: Border.all(color: Colors.cyanAccent.withOpacity(0.5)),
            borderRadius: BorderRadius.circular(8.0),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start, 
                children: [
                  const Icon(Icons.analytics_outlined, color: Colors.cyanAccent, size: 20),
                  const SizedBox(width: 8),
                  Expanded( 
                    child: Text(
                      'TACTICAL DOSSIER:\n${data['title']}', 
                      style: const TextStyle(
                        color: Colors.cyanAccent,
                        fontSize: 15, 
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.0,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                data['body']!,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'RECOMMENDED ACQUISITION: ',
                    style: TextStyle(color: Colors.white54, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                  ),
                  Expanded( 
                    child: Text(
                      data['suggested_item']!.toUpperCase(),
                      style: const TextStyle(color: Colors.amberAccent, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'Orbitron'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}